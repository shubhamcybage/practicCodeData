package com.java.Iterable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Example_3 {

	public static void main(String[] args) {

		List<String> list = new ArrayList<>();
		list.add("Geeks");
		list.add("for");
		list.add("Shubham");
		
		Iterator<String> iterator = list.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
