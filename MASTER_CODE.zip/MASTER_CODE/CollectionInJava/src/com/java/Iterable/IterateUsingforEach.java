package com.java.Iterable;

import java.util.ArrayList;
import java.util.List;

public class IterateUsingforEach  {

	public static void main(String[] args) {
		
		List<String> list=new ArrayList<String>();
		list.add("Kaliya");
		list.add("Sourabh");
		list.add("Swaraj");
		
		list.forEach((x)->{
			System.out.println(x);
		});

	}

}
