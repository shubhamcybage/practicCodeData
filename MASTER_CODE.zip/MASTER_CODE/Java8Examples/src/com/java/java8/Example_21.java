package com.java.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

//21.Write a Java Program to find the Word with Highest Lenght ?

public class Example_21 {

	public static void main(String[] args) {

		List<String> words = Arrays.asList("GFG", "Geeks", "for", "GeeksQuiz", "GeeksforGeeks");

		Optional<String> longestString = words.stream()
				.reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2);
		System.out.println(longestString);

	}

}
