package com.java.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

//14.Write a java program to check if the number is prime or not using Java 8 ? 
public class Example_14 {

	  public static boolean isPrime(int number) {
	        for (int i = 2; i <= number / 2; i++) {
	            if (number % i == 0) {
	                return false;
	            }
	        }
	        return true;
	    }

	public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(5, 7, 4, 9, 22, 66, 55, 1, 8);
        // Prime number 
        System.out.println(numbers.stream().filter(Example_14::isPrime).collect(Collectors.toList()));
    }

}
