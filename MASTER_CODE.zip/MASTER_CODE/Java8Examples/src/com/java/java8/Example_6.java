package com.java.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//6.Write a Java Program to Print the Numbers that starts with Prefix using Java 8 ? 

public class Example_6 {

	public static void main(String[] args) {

        List<Integer> list=Arrays.asList(25,1,2,6,225,5,7);
        
        List<Integer> noList=list.stream().map(e->String.valueOf(e))
        		.filter(e->e.startsWith("2")).map(Integer::valueOf).collect(Collectors.toList());
        System.out.println(noList);
        
       
	}

}
