package com.java.java8;

import java.util.ArrayList;
//12.Write a Java Program to Count the no of occurance of words in given string using Java 8 ?
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Example_12 {

	public static void main(String[] args) {

		String str="My Name is Shubham";
		List<String> list=Arrays.asList(str.split(" "));
		System.out.println(list);
		Map<String,Long> fList=list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(fList);
		
		Employee e1=new Employee("Shubham",18);
		Employee e2=new Employee("Rahul",87);
		Employee e3=new Employee("Sanket",98);
		Employee e4=new Employee("Shakank",14);
		Employee e5=new Employee("Deepak",36);
		Employee e6=new Employee("Harshal",47);
		Employee e7=new Employee("Gaurav",74);
		Employee e8=new Employee("Gaurav",74);
		
		
		
		List<Employee> empList=new ArrayList<>();
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		empList.add(e6);
		empList.add(e7);
		empList.add(e8);
		
		int l=empList.stream().max(Comparator.comparing(Employee::getAge)).get().getAge();
		System.out.println(l);
		
		Map<String,Long> finalList=empList.stream().map(e->e.getName()).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(finalList);
	
	}
}
