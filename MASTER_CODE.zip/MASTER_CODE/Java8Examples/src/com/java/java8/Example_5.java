package com.java.java8;

import java.util.Arrays;
import java.util.List;import java.util.stream.Collector;
import java.util.stream.Collectors;

//5.Write a Java Program to Print Even and Odd Numbers from the list using Java 8 ?

public class Example_5 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(5, 7, 4, 9, 22, 66, 55, 1, 8);
		// Even Numbers
		List<Integer> evenList = list.stream().filter(e -> e % 2 == 0).collect(Collectors.toList());
		System.out.println(evenList);
		
		//Odd
		List<Integer> oddList=list.stream().filter(e->e%2!=0).collect(Collectors.toList());
		System.out.println(oddList);
	}

}
