package com.java.java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;


//8.Write a Java Program to Print the Max and Min numbers from the List using Java 8 ?

public class Example_8 {

	public static void main(String[] args) {
		
		  List<Integer> list=Arrays.asList(25,1,2,6,225,5,5,7);
          int maxValue=list.stream().max(Comparator.comparing(Integer::valueOf)).get();
		  int minValue=list.stream().min(Comparator.comparing(Integer::valueOf)).get();
          System.out.println("Min Value : "+minValue);
		  System.out.println("Max Value : "+maxValue);
		  
		  int maxValue1=list.stream().max(Comparator.comparing(Integer::valueOf)).get();
		  int minValue2=list.stream().min(Comparator.comparing(Integer::valueOf)).get();
		  System.out.println(" Maximum Value : "+ maxValue1 + " Minimum Value : "+ minValue2);
		  
		  list.stream().max(Comparator.comparing(Integer::valueOf)).get();
	}

}
