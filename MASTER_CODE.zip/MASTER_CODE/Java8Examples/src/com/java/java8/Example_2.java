package com.java.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

//2.Wirte a Java Program to Print Even Numbers from the list using Java 8?

public class Example_2 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(4, 9, 8, 3, 2, 6, 7, 44, 22);
		List<Integer> value = list.stream().filter(e -> e % 2 == 0).collect(Collectors.toList());
		System.out.println(value);

	}

}
