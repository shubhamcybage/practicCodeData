package com.java.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//10.Write a Java Program to get/Ignore first 5 numbers using Limit & Skip using Java 8 ? 

public class Example_10 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(25,1,2,6,225,5,5,7);
		
		List<Integer> limitList=list.stream().limit(5).collect(Collectors.toList());
		System.out.println(limitList);
		
		List<Integer> skipList=list.stream().skip(5).collect(Collectors.toList());
		System.out.println(skipList);
	}

}
