package com.java.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Product {
	int id;
	String name;
	double price;

	public Product(int id, String name, double price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}
}

public class Example_13 {

	public static void main(String[] args) {

		List<Product> productsList = new ArrayList<Product>();
		productsList.add(new Product(1, "HP Laptop", 25000f));
		productsList.add(new Product(2, "Dell Laptop", 30000f));
		productsList.add(new Product(3, "Lenevo Laptop", 28000f));
		productsList.add(new Product(4, "Sony Laptop", 28000f));
		productsList.add(new Product(5, "Apple Laptop", 90000f));

		List<Double> priceList=productsList.stream().filter(e->e.price>20000).map(e->e.price).collect(Collectors.toList());
		
		System.out.println(priceList);

		Stream<Object> sumPrice=productsList.stream().map(e->e.price);
		
		System.out.println(sumPrice);
		
        double totalPrice1=productsList.stream().collect(Collectors.summingDouble(e->e.price)).doubleValue();
        
		System.out.println(totalPrice1);
	}

}
