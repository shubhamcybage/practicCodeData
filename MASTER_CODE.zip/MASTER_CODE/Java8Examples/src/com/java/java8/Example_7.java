package com.java.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

//7.Write a Java Program to Print the Duplicate Numbers using Java 8 ?

public class Example_7 {

	public static void main(String[] args) {

		// Approach 1
		List<String> list = Arrays.asList("Shubham","Shubham","Hello","Hi");
//      Set<Integer> value=list.stream().filter(e->Collections.frequency(list,e)>1).collect(Collectors.toSet());
//      System.out.println(value);

		// Approach 2
		Set<String> duplicateElement = new HashSet();
		List<String> valueList = list.stream().filter(e -> !duplicateElement.add(e)).collect(Collectors.toList());
		System.out.println(valueList);
		
		Set<String> duplicates=new HashSet<>();
		List<String> valueList1=list.stream().filter(e->!duplicates.add(e)).collect(Collectors.toList());
		System.out.println(valueList1);

	}
}
