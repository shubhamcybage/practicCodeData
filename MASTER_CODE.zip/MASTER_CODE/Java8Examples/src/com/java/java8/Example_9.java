package com.java.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

//9.Write a Java Program to Sort the Numbers in Ascending or Decending Orders using Java 8 ?

public class Example_9 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(25, 1, 2, 6, 225, 5, 5, 7);
		List<Integer> valueList = list.stream().sorted().collect(Collectors.toList());
		System.out.println(valueList);
		
		List<Integer> valueList1=list.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println(valueList1);
		
		List<Integer> list1 = Arrays.asList(5, 7, 4, 9, 22, 66, 55, 1, 8);
		List<Integer> finalList=list1.stream().sorted().collect(Collectors.toList());
		System.out.println(finalList);
		
		List<Integer> finalList2=list.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println(finalList2);
	}

}
