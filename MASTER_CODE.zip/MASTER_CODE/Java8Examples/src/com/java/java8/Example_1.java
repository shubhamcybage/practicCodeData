package com.java.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

//1.Write a Java Program to Print Sum of All the Numbers using Java 8?

public class Example_1 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(4, 8, 9, 6, 2, 3, 4, 7, 6, 5);
		int value = list.stream().reduce((a, b) -> (a + b)).get();
		System.out.println(value);

		int sum = list.stream().reduce((a, b) -> (a + b)).get();
		System.out.println(sum);

		List<Integer> list1 = Arrays.asList(4, 8, 9, 5, 6, 3, 5, 7, 6);
		int sumValue = list1.stream().reduce((a, b) -> (a + b)).get();
		System.out.println(sumValue);

		List<String> words = Arrays.asList("GFG", "Geeks", "for", "GeeksQuiz", "GeeksforGeeks");

		Optional<String> longestString = words.stream()
				.reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2);
		System.out.println(longestString);

		List<String> words1 = Arrays.asList("Shubham", "Shubham Nagpure");
		String value1 = words1.stream().reduce((w1, w2) -> w1.length() > w2.length() ? w1 : w2).get();
		System.out.println(value1);

	}

}
