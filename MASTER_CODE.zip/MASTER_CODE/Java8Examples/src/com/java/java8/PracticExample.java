package com.java.java8;

import java.util.*;
import java.util.stream.Collectors;

public class PracticExample {

	  public static boolean isPrime(int number) {
	        for (int i = 2; i <= number / 2; i++) {
	            if (number % i == 0) {
	                return false;
	            }
	        }
	        return true;
	    }


	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(5, 7, 4, 9, 22, 66, 55, 1, 8);
		List<Integer> finalList = list.stream().filter(PracticExample::isPrime).collect(Collectors.toList());
		System.out.println(finalList);
	}

}
