package com.java.java8;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

//18.Write a Java Program to sort the Map using Java 8 feature ?

public class Example_18 {

	public static void main(String[] args) {
		
		Map<String,Integer> unsortedMap=new HashMap<>();
		
		unsortedMap.put("a",1);
		unsortedMap.put("b",8);
		unsortedMap.put("e",6);
		unsortedMap.put("h",7);
		unsortedMap.put("q",4);
		unsortedMap.put("o",3);
		unsortedMap.put("x",2);
		unsortedMap.put("m",6);
	
		
		Map<String,Integer> sortMap=new LinkedHashMap<>();
		unsortedMap.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEachOrdered(e->sortMap.put(e.getKey(),
				e.getValue()));
		
		unsortedMap.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEachOrdered(e->sortMap.put(e.getKey(),e.getValue()));
		
		System.out.println(sortMap);
		

		unsortedMap.entrySet().forEach(System.out::println);
		

	}

}
