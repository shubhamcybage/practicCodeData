package com.java.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

//11.Write a Java Program to get the Second Highest and Lowest Number from the List ? 

public class Example_11 {

	public static void main(String[] args) {
	
		//Finding the Second Highest
		List<Integer> list = Arrays.asList(25, 1, 2, 6, 225, 5, 5, 7);
		Integer secondList=list.stream().sorted(Collections.reverseOrder()).skip(1).findFirst().get();
		System.out.println(secondList);
		
		//Finding the lowest Number
		int lowestNumber=list.stream().sorted().skip(1).findFirst().get();
		System.out.println(lowestNumber);
		
		
	}

}
