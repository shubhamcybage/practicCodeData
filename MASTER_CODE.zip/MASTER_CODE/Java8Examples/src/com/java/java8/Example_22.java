package com.java.java8;

import java.util.*;
import java.util.stream.Collectors;

//22.Write a Java Program to fetch the list from Map using flatMap ?

public class Example_22 {

	public static void main(String[] args) {
	
		Map<String,List<String>> peopleNameAndPhoneMap=new HashMap<>();
		peopleNameAndPhoneMap.put("Shubham",Arrays.asList("854613397","7845697413"));
		peopleNameAndPhoneMap.put("Akashay",Arrays.asList("741269566","85269842"));
		
		List<String> phoneList=peopleNameAndPhoneMap.values().stream()
				.flatMap(Collection::stream).collect(Collectors.toList());
		
		System.out.println(phoneList);

	}

}
