package com.java.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

//15.Write a java program to group the Employees based on the same age use grouppingBy Java 8 feature ? 

public class Example_15 {

	public static void main(String[] args) {
		
		List<Employee> employeeList=new ArrayList<Employee>();
		employeeList.add(new Employee("Shubham",5));
		employeeList.add(new Employee("Rahul",5));
		employeeList.add(new Employee("Sham",10));
		employeeList.add(new Employee("Ritik",5));
		employeeList.add(new Employee("Laksham",2));
		employeeList.add(new Employee("Sharma",7));
		
		Map<Object, Set<Employee>> mapList=employeeList.stream()
				.collect(Collectors.groupingBy(e->e.getAge(),TreeMap::new,Collectors.toSet()));
		
		Map<Object, Set<Employee>> mapList1=employeeList.stream()
				.collect(Collectors.groupingBy(e->e.getAge(),TreeMap::new,Collectors.toSet()));
		
		System.out.println(mapList);
		
		Map<Integer, Set<String>> map3 =  employeeList.stream()
                .collect(Collectors.groupingBy
                        (Employee::getAge, Collectors.mapping
                                (Employee::getName, Collectors.toSet())));
		
		System.out.println(map3);


	}

}
