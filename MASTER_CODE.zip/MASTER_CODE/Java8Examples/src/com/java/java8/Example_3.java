package com.java.java8;

import java.util.Arrays;
import java.util.List;

//3.Write a Java Program to Print the Average of all the Numbers using Java 8 ? 

public class Example_3 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(4, 7, 8, 9, 6, 3);
		double value = list.stream().mapToInt(e -> e).average().getAsDouble();
		System.out.println(value);
		
		double value1=list.stream().mapToInt(e->e).summaryStatistics().getMax();
		System.out.println(value1);
		
		
		list.stream().mapToInt(e->e).summaryStatistics().getAverage();
		
		double value2=list.stream().mapToInt(e->e).average().getAsDouble();
		
		
		
	}

}
