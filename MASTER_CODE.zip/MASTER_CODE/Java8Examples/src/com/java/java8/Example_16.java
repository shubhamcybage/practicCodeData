package com.java.java8;

import java.util.Arrays;
import java.util.List;

//16.Write a Java program to Get Count , min , max , sum and the average of the Numbers using stream().mapToInt(e->e).summaryStatistics() ?
public class Example_16 {

	public static void main(String[] args) {
		
		List<Integer> list=Arrays.asList(4,8,9,77,22,66,5,4,99,85,59);
		Long value=list.stream().mapToInt(e->e).summaryStatistics().getCount();
		System.out.println(value);
		
		

	}

}
