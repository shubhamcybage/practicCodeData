package com.java.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Example_17 {

	public static void main(String[] args) {

		List<Employee> employeeList=new ArrayList<Employee>();
		employeeList.add(new Employee("Shubham",5));
		employeeList.add(new Employee("Rahul",5));
		employeeList.add(new Employee("Sham",10));
		employeeList.add(new Employee("Ritik",5));
		employeeList.add(new Employee("Laksham",2));
		employeeList.add(new Employee("Sharma",7));
		String value=employeeList.stream().map(e->e.getName()).collect(Collectors.joining(","));
		System.out.println(value);
		
	}
}
