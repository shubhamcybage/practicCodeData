package com.java.immutableClass;

//Make Class as Final
//Make Variable as Private 
//Make Varibale as Final 
//Make deep Copy of the Objects
class Engine {
	int speed;
	Engine(int speed) {
		this.speed = speed;
	}
}

public final class ImmutableClass {

	private final int id;
	private final String name;
	private final Engine engine;

	public ImmutableClass(int id, String name,Engine engine) {
		super();
		this.id = id;
		this.name = name;
		Engine engineNew=new Engine(engine.speed);
		this.engine=engineNew;
	}



	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public static void main(String[] args) {
		Engine e=new Engine(50);
		ImmutableClass a = new ImmutableClass(1, "Shubham",e);
		e.speed=100;
		System.out.println(a.engine.speed);
	}

}
