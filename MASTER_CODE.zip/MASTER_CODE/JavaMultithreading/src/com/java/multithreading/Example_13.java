package com.java.multithreading;

//13.Write a Java Program for the Synchronized() block ? 

class BookTheatureSeats12 {

	int total_seats = 10;

	void bookSeat(int seats) {
		
		synchronized (this) {
			
			if (total_seats >= seats) {
				System.out.println(seats + " Seats booked successfully");
				total_seats = total_seats - seats;
				System.out.println("Total seats left :" + total_seats);

			}
		}

	}

}

public class Example_13 extends Thread {

	static BookTheatureSeats12 b;
	int seats;

	public void run() {

		b.bookSeat(seats);

	}

	public static void main(String[] args) {

		b = new BookTheatureSeats12();
		Example_13 ex13 = new Example_13();
		ex13.seats = 7;
		ex13.start();

		Example_13 ex131 = new Example_13();
		ex131.seats = 6;
		ex131.start();

	}

}
