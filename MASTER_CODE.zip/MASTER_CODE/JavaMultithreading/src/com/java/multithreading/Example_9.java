package com.java.multithreading;

//9.Write a Java Program to for the interrupt() methos for the methods ?

public class Example_9 extends Thread {

	public void run() {

		try {
			System.out.println("Thread is executing......");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			System.out.println("Thread is interrupted");
		}
	}

	public static void main(String[] args) {

		Example_9 ex9 = new Example_9();
		ex9.start();
		ex9.interrupt();

	}

}
