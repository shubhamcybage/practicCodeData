package com.java.multithreading;

public class Practic implements Runnable {

	static int total_earnings = 0;

	public void run() {

		synchronized (this) {
			for (int i = 0; i <= 5; i++) {
				total_earnings += 100;
			}
			this.notify();
		}
	}

	public static void main(String[] args) throws InterruptedException {

		Practic p = new Practic();
		Thread th = new Thread(p);
		th.start();

		synchronized (th) {
			th.wait();
		}
		System.out.println("Total Earnings : " + total_earnings);

	}

}
