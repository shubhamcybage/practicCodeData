package com.java.multithreading;

public class Example_1 extends Thread {

	public void run() {
		
		System.out.println("Thread is created.....");
	}

	public static void main(String[] args) {

		Example_1 ex1 = new Example_1();
		ex1.start();

	}

}
