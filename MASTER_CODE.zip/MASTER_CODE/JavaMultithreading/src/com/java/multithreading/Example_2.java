package com.java.multithreading;

public class Example_2 implements Runnable {

	@Override
	public void run() {
		
		System.out.println("Thread is Created...........");
	}

	public static void main(String[] args) {
		Example_2 ex2 = new Example_2();
		Thread th = new Thread(ex2);
		th.start();
	}

}
