package com.java.multithreading;

public class Example_5 extends Thread{
	
	public void run() {
		
		Thread.currentThread().setPriority(10);
		System.out.println("Priority for the thread :  "+Thread.currentThread().getPriority());
		
	}

	public static void main(String[] args) {
		
		System.out.println("Priority for the thread :  "+Thread.currentThread().getPriority());
		Example_5 ex5=new Example_5();
		Thread.currentThread().setPriority(10);
		System.out.println("Priority for the thread :  "+Thread.currentThread().getPriority());
		ex5.start();
	}

}
