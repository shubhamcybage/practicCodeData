package com.java.multithreading;

//11.Write a Java Program for the Synchronization ? 

class BookTheatureSeats{

	int total_seats=10;
	void bookSeat(int seats) {
		
		if(total_seats>=seats) {
			
			System.out.println(seats+" Seats booked successfully");
			total_seats=total_seats-seats;
			System.out.println("Total seats left :"+total_seats);
			
		}
		
	}
	
	
}

public class Example_11 extends Thread{
	
	static BookTheatureSeats b;
	int seats;
	public void run() {
		
		b.bookSeat(seats);
		
	}

	public static void main(String[] args) {
		
		b=new BookTheatureSeats();
		Example_11 ex11=new Example_11();
		ex11.seats=7;
		ex11.start();
		
		Example_11 ex111=new Example_11();
		ex111.seats=6;
		ex111.start();


	}

}
