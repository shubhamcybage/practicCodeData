package com.java.multithreading;

//10.Write a Java Program to for the interrupted() & isInterrupted() method for the methods ?

public class Example_10 extends Thread {
	
	public void run() {
		
		// System.out.println(Thread.currentThread().interrupted());
	//	 System.out.println(Thread.currentThread().isInterrupted());
		
		System.out.println(Thread.currentThread().interrupted());
		System.out.println(Thread.currentThread().interrupted()); 
		for (int i = 0; i < 5; i++) {
			try {
				System.out.println("Print Status :"+i);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
	}

	public static void main(String[] args) {

		Example_10 ex10=new Example_10();
		ex10.start();
		ex10.interrupt();

	}

}
