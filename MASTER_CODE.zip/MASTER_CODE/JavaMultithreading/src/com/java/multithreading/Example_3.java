package com.java.multithreading;

//3.Write a Java Program for Thread using getName(),setName() , currentThread() and isAlive() method ? 

public class Example_3 extends Thread {

	public void run() {
        
		Thread.currentThread().setName("Shubham_1");
		System.out.println("Thread is executing name is " + Thread.currentThread().getName());
		
		
	}

	public static void main(String[] args) {

		Thread.currentThread().setName("Shubham");
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().isAlive());
		
		Example_3 ex3=new Example_3();
		ex3.start();
		System.out.println(Thread.currentThread().isAlive());

	}

}
