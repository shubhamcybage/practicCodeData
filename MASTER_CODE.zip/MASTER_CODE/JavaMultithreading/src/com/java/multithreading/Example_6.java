package com.java.multithreading;
//6.Write a Java Program to for the sleep(long mili) methos for the methods ?
public class Example_6 extends Thread{
	
	public void run() {
		
		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(1000);
				System.out.println("Print : "+i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
		}
	}

	public static void main(String[] args) throws InterruptedException {
		
		Example_6 ex6=new Example_6();
		ex6.start();
		
		Example_6 ex61=new Example_6();
		ex61.start();


	}

}
