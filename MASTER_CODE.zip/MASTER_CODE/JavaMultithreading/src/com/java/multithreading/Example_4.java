package com.java.multithreading;

//4.Write a Java Program to create a Daemon Thread with isDaemon() , setDaemon(boolean b) methods ?

public class Example_4 extends Thread {

	public void run() {

		System.out.println("Thread is running.....");
		System.out.println(Thread.currentThread().isDaemon());
	}

	public static void main(String[] args) {

		//System.out.println("Main Thread.........");
		Example_4 ex4 = new Example_4();
		ex4.setDaemon(true);
		ex4.start();
		System.out.println(Thread.currentThread().isDaemon());

	}

}
