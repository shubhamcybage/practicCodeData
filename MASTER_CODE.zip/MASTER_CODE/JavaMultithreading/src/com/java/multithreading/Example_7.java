package com.java.multithreading;

public class Example_7 extends Thread {

	public void run() {

		for (int i = 0; i < 5; i++) {

			System.out.println("Print run  :"+i);
			
		}

	}

	public static void main(String[] args) {
		
		Example_7 ex7=new Example_7();
		ex7.start();
		
		Thread.yield();
		
		for (int i = 0; i < 5; i++) {
			
			System.out.println("Print main:"+i);

		}

	}

}
