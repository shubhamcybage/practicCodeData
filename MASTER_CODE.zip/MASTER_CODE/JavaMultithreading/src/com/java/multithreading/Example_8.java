package com.java.multithreading;

//8.Write a Java Program to for the Join() methods for the methods ?

class Medical extends Thread {

	public void run() {

		try {

			System.out.println("Medical is Started.......");
			Thread.sleep(1000);
			System.out.println("Medical is Complicated......");

		} catch (Exception e) {

		}

	}

}

class TestDrive extends Thread {

	public void run() {

		try {

			System.out.println("TestDrive is Started.......");
			Thread.sleep(1000);
			System.out.println("TestDrive is Complicated......");

		} catch (Exception e) {

		}

	}

}

class OfficerSign extends Thread {

	public void run() {

		try {

			System.out.println("OfficerSign is Started.......");
			Thread.sleep(1000);
			System.out.println("OfficerSign is Complicated......");

		} catch (Exception e) {

		}

	}

}

public class Example_8 {

	public static void main(String[] args) throws InterruptedException {

		Medical med = new Medical();
		med.start();
		
		med.join();
		
		TestDrive td = new TestDrive();
		td.start();
		
		td.join();

		OfficerSign os = new OfficerSign();
		os.start();
		
		os.join();

	}

}
