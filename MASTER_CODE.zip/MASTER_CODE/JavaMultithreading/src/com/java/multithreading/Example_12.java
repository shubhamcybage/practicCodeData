package com.java.multithreading;

//11.Write a Java Program for the Synchronization ? 

class BookTheatureSeats1 {

	int total_seats = 10;

	synchronized void bookSeat(int seats) {

		if (total_seats >= seats) {

			System.out.println(seats + " Seats booked successfully");
			total_seats = total_seats - seats;
			System.out.println("Total seats left :" + total_seats);

		}

	}

}

public class Example_12 extends Thread {

	static BookTheatureSeats1 b;
	int seats;

	public void run() {

		b.bookSeat(seats);

	}

	public static void main(String[] args) {

		b = new BookTheatureSeats1();
		Example_12 ex12 = new Example_12();
		ex12.seats = 7;
		ex12.start();

		Example_12 ex121 = new Example_12();
		ex121.seats = 6;
		ex121.start();

	}

}
