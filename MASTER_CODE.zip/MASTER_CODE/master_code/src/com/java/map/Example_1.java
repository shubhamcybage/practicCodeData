package com.java.map;

import java.util.HashMap;
import java.util.Map;

public class Example_1 {

	public static void main(String[] args) {

		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "Shubham");
		map.put(2, "Nagpure");
		map.put(3, "Rahul");
		map.put(1,"Kaliya");

		System.out.println("Iterating Hashmap...");
		for (Map.Entry m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

	}

}
