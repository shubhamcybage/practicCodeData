package com.java.sorting;

import java.util.HashMap;
import java.util.Set;


public class NewEx_4 {
	
	public static void duplicateElementInArray(int[] arr) {
		
		HashMap<Integer,Integer> map=new HashMap<>();
		for(int a:arr) {
			if(map.containsKey(a)) {
				map.put(a,map.get(a)+1);
			}else {
				map.put(a, 1);
			}
		}
		
		Set<Integer> set=map.keySet();
		for(Integer x:set) {
			if(map.get(x)>1) {
				System.out.println(x + " is : " + map.get(x) + " times ");
			}
		}
		
	}

	public static void main(String[] args) {
        int[] arr= {8,9,6,3,7,45,41,41,1,7,77};
		NewEx_4.duplicateElementInArray(arr);

	}

}
