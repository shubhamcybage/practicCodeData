package com.java.sorting;
//5.Write a Hava Program to find the largest Element in the Array ? 
public class print2LargestElement {

	public static void print2largest(int arr[], int arr_size) {
		int first,second;
		if(arr.length<2) {
			System.out.println("Invalid Input....");
			return;
		}
		
		first=second=Integer.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]>first) {
				second=first;
				first=arr[i];
			}else if(arr[i]>second && arr[i]!=second) {
				second=arr[i];
			}
		}
		System.out.println(second);		
	}

	public static void main(String[] args) {
		int arr[] = { 12, 35, 1, 10, 34, 1 };
		int n = arr.length;
		print2largest(arr, n);
	}
}
