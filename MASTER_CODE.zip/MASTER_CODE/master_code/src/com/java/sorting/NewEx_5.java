package com.java.sorting;

public class NewEx_5 {
	
	public static int largestElement(int[] arr) {
	
		int max=arr[0];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		return max;
		
	}

	public static void main(String[] args) {
	
		int[] arr= {5,7,89,23,5,6,9,4,1};
		int lar=largestElement(arr);
		System.out.println(lar);

	}

}
