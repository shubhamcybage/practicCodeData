package com.java.sorting;
//Bubble Sort
public class BubbleSort {

	public static void sortUsingBubbleSort(int[] arr) {
		int n=arr.length;
		for (int i = 0; i < n-1; i++) {
			boolean Swapped=false;
			for (int j = 0; j < n-i-1; j++) {
				if(arr[j+1]<arr[j]) {
					Swapped=true;
					int temp=arr[j+1];
					arr[j+1]=arr[j];
					arr[j]=temp;
				}
			}
			if(!Swapped) {
				break;
			}
		}
	}


	public static void main(String[] args) {

		int[] arr={4,89,1,23,45,6,9,7,4,5,2};
		System.out.println("Array Before Sorting.....");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		BubbleSort.sortUsingBubbleSort(arr);
		System.out.println("Array After Sorting.......");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	

	}

}
