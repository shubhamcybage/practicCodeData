package com.java.comparableAndComparable;

import java.util.Scanner;

public class Ex_2 {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			System.out.println(" try without catch/finally block ");
		}
	}

}
