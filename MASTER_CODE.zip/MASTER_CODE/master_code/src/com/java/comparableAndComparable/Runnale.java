package com.java.comparableAndComparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Runnale {

	public static void main(String[] args) {

		List<Laptop> list = new ArrayList<Laptop>();

		list.add(new Laptop("Dell", 8, 100.00));
		list.add(new Laptop("Leveno", 8, 145.00));
		list.add(new Laptop("Sony", 32, 1458.00));
		list.add(new Laptop("Apple", 64, 458.00));
		list.add(new Laptop("HP", 4, 8965.00));

		Comparator<Laptop> lp = new Comparator<Laptop>() {
            public int compare(Laptop l1,Laptop l2) {
            	if(l1.getPrice()>l2.getPrice()) {
            		return 1;
            	}else {
            		return -1;
            	}
            
            }
		};

		Collections.sort(list,lp);

		for (Laptop l : list) {
			System.out.println(l);
		}

	}

}
