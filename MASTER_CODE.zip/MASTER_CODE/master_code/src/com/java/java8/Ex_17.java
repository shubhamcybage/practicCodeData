package com.java.java8;

interface Sayable45 {

	default void say() {
		System.out.println("This is default method....");
	}

	void saySomething(String str);

}

public class Ex_17 implements Sayable45 {

	@Override
	public void saySomething(String str) {
		System.out.println(str);
	}

	public static void main(String[] args) {
		
		Ex_17 ex17 = new Ex_17();
		ex17.saySomething("Shubham");
		ex17.say();
		
	}

}
