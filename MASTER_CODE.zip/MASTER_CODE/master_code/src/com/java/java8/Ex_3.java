package com.java.java8;

@FunctionalInterface
interface Sayable1{
	
	public String say(String name);
}

public class Ex_3 {

	public static void main(String[] args) {
		
		Sayable1 s1=name->{
			return "My Name is :"+name; 
		};
		System.out.println(s1.say("Shubham"));
	}

}
