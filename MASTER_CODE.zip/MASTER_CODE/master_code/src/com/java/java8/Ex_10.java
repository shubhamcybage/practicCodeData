package com.java.java8;

interface Sayable11{
	
	public void say();
}

public class Ex_10 {

	public static void saySomething() {
		
		System.out.println("Say Something......");
	}
	
	
	public static void main(String[] args) {
		
		Sayable11 a11=Ex_10::saySomething;
		a11.say();

	}

}
