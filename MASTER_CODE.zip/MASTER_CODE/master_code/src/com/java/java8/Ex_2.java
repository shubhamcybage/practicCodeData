package com.java.java8;

@FunctionalInterface  //it's Optional
interface Drawable{
	
	public String draw();
}

public class Ex_2 {

	public static void main(String[] args) {
		
		Drawable d=()->{
			return "Shubham id doing good Job";
		};
		System.out.println(d.draw());
	}
}
