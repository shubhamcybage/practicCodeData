package com.java.java8;

import java.util.ArrayList;
import java.util.List;

public class Ex_5 {

	public static void main(String[] args) {

		List<String> li=new ArrayList<String>();
		li.add("shubham");
		li.add("Nagpure");
		li.add("Rahul");
		
		li.forEach((x)->{
			System.out.println(x);
		});

	}

}
