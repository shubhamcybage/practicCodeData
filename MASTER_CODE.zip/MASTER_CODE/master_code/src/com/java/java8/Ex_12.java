package com.java.java8;

import java.util.function.BiFunction;

class Arithmetic{
	
	public static int add(int a, int b) {
		return a+b;
	}
}

public class Ex_12 {

	public static void main(String[] args) {
	
		BiFunction<Integer,Integer,Integer> bi=Arithmetic::add;
		int a=bi.apply(10,20);
		System.out.println(a);
	}

}
