package com.java.java8;

import java.util.function.BiFunction;

interface Payable {
	public void pay();
}


public class Ex_9 {

	public static void paySomething() {
		System.out.println("Pay something......");
	}

	public static void ThreadStatus() {
		System.out.println("Thread is Running.......");
	}

	public static void main(String[] args) {
		Payable payl = Ex_9::paySomething;
		payl.pay();

		Thread th = new Thread(Ex_9::ThreadStatus);
		th.start();

		BiFunction<Integer, Integer, Integer> bi = Arithmetic::add;
		int c = bi.apply(10, 20);
		System.out.println(c);
	}
}