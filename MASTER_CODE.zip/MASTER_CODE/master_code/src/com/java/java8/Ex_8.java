package com.java.java8;

import java.util.Optional;

public class Ex_8 {

	public static void main(String[] args) {
		String[] str = new String[10];
		str[5] = "My name is Shubham";
		Optional<String> checkNull = Optional.ofNullable(str[5]);
		if (checkNull.isPresent()) {
			String str1 = str[5].toLowerCase();
			System.out.println(str1);
			checkNull.ifPresent(System.out::println);
			System.out.println(checkNull.get());
		}

		Optional<String> empty = Optional.empty();
		System.out.println(empty);

		Optional<String> value = Optional.of(str[5]);
		System.out.println("Filtered value: " + value.filter((s) -> s.equals("My name is Shubham")));

		System.out.println("Getting value: " + value.get());
		System.out.println("Is value present: " + value.isPresent());
		
        System.out.println("Nullable Optional: "+Optional.ofNullable(str[5]));  
        
        System.out.println("orElse: "+value.orElse("Value is not present"));  
        System.out.println("orElse: "+empty.orElse("Value is not present"));  
	}

}
