package com.java.java8.functionalInterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerInterfaceDemo {

	public static void main(String[] args) {

		//Example 1
		
		Consumer<String> consumer = (String t) -> System.out.println(t);
		consumer.accept("Shubham");
		
		//Example 2
		
		Consumer<String> consumer1 = (t) -> System.out.println(t + " World ");
		Consumer<String> consumer2 = (t) -> System.out.println(t + " Java ");
		consumer1.andThen(consumer2).accept("Shubham");
		
		//Example 3
		
		List<Integer> integer=Arrays.asList(1,8,9,74,36,6,65);
		//Consumer<Integer> consumer3 = (Integer t) -> System.out.println(t);
		integer.forEach((t)->System.out.println(t));

	}
}
