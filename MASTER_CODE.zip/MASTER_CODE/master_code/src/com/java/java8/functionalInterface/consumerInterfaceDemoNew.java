package com.java.java8.functionalInterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class consumerInterfaceDemoNew {

	public static void main(String[] args) {

		Consumer<String> consumer= (name) ->System.out.println("Consumer Interface........" + name);
		consumer.accept("Shubham");
		
		
		Consumer<String> consumer1 = (input) ->System.out.println(input + "World!");
		Consumer<String> consumer2 = (input) ->System.out.println(input + "Java!");
		consumer2.andThen(consumer1).accept("Shubham");
		
		
		List<Integer> integer=Arrays.asList(4,8,7,9,6,3);
		Consumer<Integer> consumer4=(x)->{
			System.out.println(x);
		};
		integer.forEach(consumer4);
	
	}
}
