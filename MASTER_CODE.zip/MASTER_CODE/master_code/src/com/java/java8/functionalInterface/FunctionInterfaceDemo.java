package com.java.java8.functionalInterface;

import java.util.function.Function;

public class FunctionInterfaceDemo {

	public static void main(String[] args) {

		//Example 1
		
		Function<String, Integer> function = (t) -> {
			return t.length();
		};
		System.out.println(function.apply("Shubham"));
		
		//Example 2
		
		Function<Integer, String> function1 = (t) -> {
			if(t%2==0) {
				return " Number " + t + " is even ";
			}else {
				return " Number " + t +" is odd ";
			}
		};
		System.out.println(function1.apply(12));
		
		//Example 3
		
		Function<String, Integer> function2=(t)->t.length();
		Function<Integer, Integer> function3=(num)->num*2;
		
		Integer integer=function2.andThen(function3).apply("Shubham");
		System.out.println(integer);
		
		
	}
}