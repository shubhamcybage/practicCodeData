package com.java.java8.functionalInterface;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SupplierInterfaceDemo {

	public static void main(String[] args) {

		Supplier<LocalDate> supplier = () ->  LocalDate.now();
		System.out.println(supplier.get());
		
		Supplier<List<Products>> supplierProducts=()->{
			List<Products> productsList=new ArrayList<>();
			productsList.add(new Products("Dell",101));
			productsList.add(new Products("HP",102));
			productsList.add(new Products("Black",103));
			productsList.add(new Products("White",104));
			return productsList;	
		};
		
		System.out.println(supplierProducts.get());
	}
}
