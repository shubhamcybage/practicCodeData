package com.java.java8.functionalInterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class NewEx_1 {

	public static void main(String[] args) {

		//Example 1
		
		Consumer<String> consumer1 = (t) ->System.out.println(t);
		consumer1.accept("Shubham");
		
		//Example 2
		
		Consumer<String> consumer2=(input)-> System.out.println(input + "World !");
		Consumer<String> consumer3=(input)-> System.out.println(input + "Java");
		consumer2.andThen(consumer3).accept("Hello");
		
		//Example 3
		
		List<Integer> integer=Arrays.asList(1,2,3,4,5,6,7,8,8);
		Consumer<Integer> consumer4=(input)-> System.out.println(input);
		integer.forEach(consumer4);
		
		
	}

}
