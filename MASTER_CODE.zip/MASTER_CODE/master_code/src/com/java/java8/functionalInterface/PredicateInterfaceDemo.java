package com.java.java8.functionalInterface;

import java.util.function.Predicate;

public class PredicateInterfaceDemo {

	public static void main(String[] args) {
		Predicate<Integer> predicate = new Predicate<Integer>() {
			public boolean test(Integer t) {
				if (t % 2 == 0) {
					return true;
				} else {
					return false;
				}
			}
		};
		System.out.println(predicate.test(11));

	}
}
