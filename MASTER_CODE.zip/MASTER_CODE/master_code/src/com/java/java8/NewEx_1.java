package com.java.java8;

import java.util.ArrayList;
import java.util.List;

//What are different ways of iterating collection list in Java 8?
public class NewEx_1 {

	public static void main(String[] args) {

		List<String> notes = new ArrayList<>();
		notes.add("notes1");
		notes.add("notes2");
		notes.add("notes3");
		notes.add("notes4");
		notes.add("notes5");
		notes.add("notes6");

		// Using lambda expression
		// Output : note1,note2,note3,note4,note5
		notes.forEach((n) -> {
			System.out.println(n);
		});
		
		//Using Stream and filter
		//Output : note2
		notes.forEach((n)->{
			if("notes3".equals(n)) {
				System.out.println(n);
			}
		});
		
		//Using Stream and filter
		//Output : note2
		notes.stream().filter(n->n.contains("notes2")).forEach(System.out::println);
		
		//Using method reference
		//Output : note1,note2,note3,note4,note5
		notes.forEach(System.out::println);
		

	}

}
