package com.java.java8.optional;

public class NewEx_1 {

	public static void main(String[] args) {
		String[] str=new String[10];
		String loweCase=str[5].toLowerCase();
		System.out.println(loweCase);
	}

}
