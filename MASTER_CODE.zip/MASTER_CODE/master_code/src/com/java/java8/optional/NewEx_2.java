package com.java.java8.optional;

import java.util.Optional;

public class NewEx_2 {

	public static void main(String[] args) {
	String[] str=new String[10];
	str[5]="shuh";
	Optional<String> nstr=Optional.ofNullable(str[5]);
	nstr.ifPresent(System.out::println);
	if(nstr.isPresent()) {
		System.out.println(nstr.get());
	}

	}

}
