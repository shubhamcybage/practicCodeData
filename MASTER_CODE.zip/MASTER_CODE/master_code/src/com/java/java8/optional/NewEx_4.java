package com.java.java8.optional;

import java.util.Optional;

public class NewEx_4 {

	public static void main(String[] args) {

//		String[] str=new String[10];
//		String lowerCase=str[15].toLowerCase();
//		System.out.println(lowerCase);

//		String[] str = new String[10];
//		str[5]="My Name is Shubham";
//		Optional<String> checkNull = Optional.ofNullable(str[5]);
//		if (checkNull.isPresent()) {
//			String lowerCase = str[5].toLowerCase();
//			System.out.println(lowerCase);
//		} else {
//			System.out.println("String Value is not Present");
//		}

		
		String[] str = new String[10];
		str[5]="My Name is Shubham";
		Optional<String> checkNull = Optional.ofNullable(str[5]);
		checkNull.ifPresent(System.out::print);
		System.out.println(checkNull.get());
	}

}
