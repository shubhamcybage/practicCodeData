package com.java.java8;

interface Sayable44 {

	public void say();
}

public class Ex_13 {

	public void saySomething() {
		
		System.out.println("Say Something.............");
	}

	public static void main(String[] args) {
		

		Sayable44 s44=new Ex_13()::saySomething;
		s44.say();

	}

}
