package com.java.java8.defaultMethod;

interface Mayable{
	
	public default void say() {
		System.out.println("Say Something");
	}
}

interface Playable{
	
	public default void say() {
		System.out.println("Say Something");
	}
}

public class NewEx_2 implements Mayable , Playable {
	
	public void say() {
		Mayable.super.say();
		Playable.super.say();
	}

	public static void main(String[] args) {
		
		NewEx_2 n2=new NewEx_2();
		n2.say();
	}

}
