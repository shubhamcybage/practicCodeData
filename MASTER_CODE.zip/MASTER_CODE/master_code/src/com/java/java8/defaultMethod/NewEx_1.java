package com.java.java8.defaultMethod;

interface Sayable{
	
	default void say() {
		System.out.println("My Name is Shubham");
	}
	
	void sayMore(String msg);
	
	static void sayLouder(String msg1) {
		System.out.println(msg1);
	}
	
}

public class NewEx_1 implements Sayable {
	
	public void sayMore(String msg) {
		System.out.println(msg);
	}
	
	public void say() {
		Sayable.super.say();
	}
	
	public static void main(String[] args) {
	
		NewEx_1 n1=new NewEx_1();
		n1.say();
		n1.sayMore("Shubham");
		Sayable.sayLouder("Shubham Nagpure");
		
	}


	

}
