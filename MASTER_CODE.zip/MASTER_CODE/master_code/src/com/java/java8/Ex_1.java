package com.java.java8;

interface Sayable {

	public void say();
}

public class Ex_1 {

	public static void main(String[] args) {

		Sayable s = new Sayable() {
			public void say() {
				System.out.println("Say Something......");
			}
		};
		s.say();
    }
}
