package com.java.java8;

public class Ex_11 {
	
	public static void ThreadStatus() {
		
		System.out.println("Thread Status is ............");
	}

	public static void main(String[] args) {
		
		Thread th=new Thread(Ex_11::ThreadStatus);
		th.start();

	}

}
