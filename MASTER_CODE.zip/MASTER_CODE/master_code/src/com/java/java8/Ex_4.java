package com.java.java8;

@FunctionalInterface
interface Addable{
	
	public int add(int a,int b);
	
}

public class Ex_4 {

	public static void main(String[] args) {
		
		Addable ad=(int a,int b)->{
			return (a+b);
		};
		
		
		System.out.println(ad.add(10, 20));
		
		
		
		
	}

}
