package com.java.java8;

public class Ex_14 {
	
	public void saySomething(){
		System.out.println("Thread is running...");
	}

	public static void main(String[] args) {
	
		Thread th=new Thread(new Ex_14()::saySomething);
		th.start();
		

	}

}
