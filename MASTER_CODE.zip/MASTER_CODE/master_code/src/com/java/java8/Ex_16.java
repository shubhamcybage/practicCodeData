package com.java.java8;

interface Messagable {

	Message getMessage(String msg);
}

class Message {

	Message(String msg1) {

		System.out.println(msg1);
	}
}

public class Ex_16 {

	public static void main(String[] args) {
		
		Messagable hello=Message::new;
		hello.getMessage("Shubham");
		
		

	}

}
