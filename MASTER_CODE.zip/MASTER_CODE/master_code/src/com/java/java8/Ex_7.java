package com.java.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

class Product {

	int id;
	String name;
	Integer price;

	public Product(int id, String name, Integer price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
}

public class Ex_7 {

	public static void main(String[] args) {

		List<Product> pList = new ArrayList<Product>();
		pList.add(new Product(1, "HP Laptop", 25000));
		pList.add(new Product(3, "Keyboard", 300));
		pList.add(new Product(2, "Dell Mouse", 150));
		pList.add(new Product(4, "Nirma", 450));

		Collections.sort(pList, (p1, p2) -> {
			return p1.price.compareTo(p2.price);
		});

		for (Product p : pList) {
			System.out.println("Id :" + p.id + "Name :" + p.name + "Price :" + p.price);
		}
		System.out.println("========================================================");
		// using lambda to filter data
		Stream<Product> filtered_data = pList.stream().filter(y->y.price>100);

		filtered_data.forEach((x) -> {
			System.out.println(x.name + ": " + x.price);
		});

	}

}
