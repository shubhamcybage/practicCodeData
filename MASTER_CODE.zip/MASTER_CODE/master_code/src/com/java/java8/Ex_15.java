package com.java.java8;

import java.util.function.BiFunction;

class Arithmetic1{
	
	public int add(int a,int b) {
		return a+b;
	}
}

public class Ex_15 {

	public static void main(String[] args) {

        BiFunction<Integer,Integer,Integer> bi=new Arithmetic1()::add;
        int a=bi.apply(10,20);
        System.out.println(a);
        

	}

}
