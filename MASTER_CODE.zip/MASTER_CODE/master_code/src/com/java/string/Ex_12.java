package com.java.string;
//12.How to count numbers of vowels and consonants in a string?
public class Ex_12 {

	public static void count(String str) {

		int vow = 0;
		int con = 0;

		String ref = "aeiouAEIOU";

		for (int i = 0; i < str.length(); i++) {
			if ((str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') || (str.charAt(i) >= 'a' && str.charAt(i) <= 'z')) {
				if (ref.indexOf(str.charAt(i)) != -1) {
					vow++;
				} else {
					con++;
				}

			}
		}
		System.out.println("Number of Vowels = " + vow + "\nNumber of Consonants = " + con);

	}

	public static void main(String[] args) {

		String str = "#GeeksforGeeks";
		count(str);

	}

}
