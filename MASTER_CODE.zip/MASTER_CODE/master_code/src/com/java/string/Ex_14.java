package com.java.string;

public class Ex_14 {

	public static void main(String[] args) {
		
		String s1="shubham";
		String s2="shubham";
		String s3=new String("shubham");
		String s4=new String("shubham");
		
		System.out.println(s1.equals(s2));//true
		System.out.println(s1==s2);//true
		System.out.println(s1.equals(s3));//true
		System.out.println(s1==s3);//false
		System.out.println(s3==s4);//false
		System.out.println(s3.equals(s4));//true
		
		char[] ch= {'s','h','u','b','h','a','m'};
		String s5=new String(ch);
		System.out.println(s5);
	}

}
