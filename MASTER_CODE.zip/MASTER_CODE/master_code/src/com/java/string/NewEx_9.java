package com.java.string;

//9.Write a java program to to count the total number of vowels and consonants in a string ?
public class NewEx_9 {
	
	public static void countConsonantsAndVowels(String str) {
		int vCount=0;
		int cCount=0;
		
		str.toLowerCase();
		
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' || str.charAt(i)=='u') {
				vCount++;
			}else if(str.charAt(i)>='a' && str.charAt(i)<='z'){
				cCount++;
			}
		}
		System.out.println("Total vowels count :"+vCount);
		System.out.println("Total consonants count :"+cCount);
	}

	public static void main(String[] args) {
         String str="My name is shubham and I not a Student";
         countConsonantsAndVowels(str);
	}

}
