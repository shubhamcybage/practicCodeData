package com.java.string;

//13.Write a program to remove a given character from a string?
public class Ex_13 {
	
	static void removeChar(String s, char c) {
		int j,count=0,n=s.length();
		char[] f=s.toCharArray();
	
		for (int i =j=0;i < f.length; i++) {
			if(f[i]!=c) {
				f[j++]=f[i];
			}else {
				count++;
			}
		
		}
		while(count>0) {
			f[j++]='\0';
			count--;
		}
		System.out.println(f);
	}

	public static void main(String[] args) {
		String s = "geeksforgeeks";
		removeChar(s, 'g');
	}
}
