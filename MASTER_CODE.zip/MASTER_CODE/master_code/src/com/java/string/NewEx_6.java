package com.java.string;

//Write a java program to find the frequency of a particular character from a given string ?
public class NewEx_6 {

	public static void main(String[] args) {
		String str = "My name is Shubham Nagpure";
		char[] charArr=str.toLowerCase().toCharArray();
		char search='n';
		int count=0;
		for(Character ch:charArr) {
			if(search==ch.charValue()) {
				count++;
			}
		}
		System.out.println("Frequency of a given character "+search+" is : "+count);

	}

}
