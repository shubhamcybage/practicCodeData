package com.java.string;

public class NewEx_12 {
	
	public static boolean onlyDigits(String str,int len) {
		for (int i = 0; i < len; i++) {
			if(!Character.isDigit(str.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
	
		String str="123456";
		int len=str.length();
		System.out.println(NewEx_12.onlyDigits(str,len));

	}

}
