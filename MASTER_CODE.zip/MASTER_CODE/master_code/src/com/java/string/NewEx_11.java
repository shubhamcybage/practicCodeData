package com.java.string;

//11.Write a java program to print first non-repeated character from the given String ?
public class NewEx_11 {
	
	static final int NO_OF_CHARS = 256;
	static char count[] = new char[NO_OF_CHARS];
	
	 static void getCharCountArray(String str)
	    {
	        for (int i = 0; i < str.length(); i++)
	            count[str.charAt(i)]++;
	    }
	 

	public static int firstNonRepeatingCharacter(String str1) {
		getCharCountArray(str1);
		int index =-1,i;
		
		for (int j = 0; j < str1.length(); j++) {
			if(count[str1.charAt(j)]==1) {
				index=j;
				break;
			}
		}
		return index;
	}

	public static void main(String[] args) {
		String str = "My name is Shubham";
		int ind=NewEx_11.firstNonRepeatingCharacter(str.toLowerCase());
		System.out.println(str.charAt(ind));

	}

}
