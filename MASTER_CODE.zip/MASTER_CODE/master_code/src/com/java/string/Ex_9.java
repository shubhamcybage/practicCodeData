package com.java.string;

//program to count the total number of occurrance of a given character in a string with loop
public class Ex_9 {

	public static void main(String[] args) {
		String input="Shubam is a shubham";
		char search='a';
		int count=0;
		for (int i = 0; i < input.length(); i++) {
			if(input.charAt(i)==search) {
				count++;
			}
		}
        System.out.println(count);
	}

}
