package com.java.string;
//program to count the total number of occurrance of a given character in a string without using loop
public class Ex_10 {
	
	static int findOccurance(String str, char search, int i) {
		
		if(i>=str.length()) {
			return 0;
		}
		int count=0;
		
		if(search==str.charAt(i)) {
			count++;
		}
		
		return count + findOccurance(str,search,i+1);
	}

	public static void main(String[] args) {
		String str="shubham is shubham";
		char search='a';
		
		int result = findOccurance(str,search,0);
		System.out.println(result);
		

	}

}
