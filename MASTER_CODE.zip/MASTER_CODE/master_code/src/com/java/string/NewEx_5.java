package com.java.string;

import java.util.HashMap;
import java.util.Set;
//5.Write a Java Program to find duplicate characters in a String ? 
public class NewEx_5 {

	public static void findDuplicates(String str) {

		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();
		char[] chaArr = str.toCharArray();
		for (Character c : chaArr) {
			if (hm.containsKey(c)) {
				hm.put(c, hm.get(c) + 1);
			} else {
				hm.put(c, 1);
			}
		}

		Set<Character> keys = hm.keySet();
		for (Character ch : keys) {
			if (hm.get(ch) > 1) {
				System.out.println(ch + " is : " + hm.get(ch) + " times ");
			}
		}

	}

	public static void main(String a[]) {
		findDuplicates("My Name is Shubham");
	}
}