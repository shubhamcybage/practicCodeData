package com.java.string;

//Reverse String Program
public class Ex_15 {

	public static void main(String[] args) {

		String str = "shubham";
		String nstr = "";
		char ch;
		for (int i = 0; i < str.length(); i++) {
			ch = str.charAt(i);
			nstr = ch + nstr;
		}
		System.out.println(nstr);
	}
}