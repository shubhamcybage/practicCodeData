package com.java.string;

//7.Write a java program to check if String is Palindrome or not ?
public class NewEx_7 {

	public static void main(String[] args) {
		String str="civic";
		StringBuilder sb=new StringBuilder(str);
		StringBuilder sb1=sb.reverse();
		if(sb.equals(sb1)) {
			System.out.println("String is Palindrom.....");
		}else{
			System.out.println("String is not Palindrom.....");
		}
	}
}
