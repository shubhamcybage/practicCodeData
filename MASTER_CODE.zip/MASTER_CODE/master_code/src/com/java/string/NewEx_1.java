package com.java.string;
//1.Write a Java Program to reverse a String in Java ?
public class NewEx_1 {

	public static void revString(String str) {
		StringBuilder sb = new StringBuilder(str);
		sb.reverse();
		System.out.println(sb);
	}
	
	public static void reverseString(String str) {
		char[] ch=str.toCharArray();
		String str1="";
		for (int i=ch.length-1;i>=0; i--) {
			str1=str1+ch[i];
		}
		System.out.println(str1);
		
	}

	public static void main(String[] args) {
		NewEx_1.revString("Shubham");
		NewEx_1.reverseString("Nagpure");
	}

}
