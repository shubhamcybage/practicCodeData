package com.java.string;

import java.util.*;

//16.Write a java program to remove duplicates characters from a given string ? 
public class NewEx_16 {

	static void removeDuplicates(String str) {
		
		LinkedHashSet<Character> set = new LinkedHashSet<>();
		for (int i = 0; i < str.length(); i++) {
			set.add(str.charAt(i));
		}
		for (Character ch : set) {
			System.out.print(ch);
		}
	}

	public static void main(String[] args) {
		String str = "MyNameisShubham";
		removeDuplicates(str);
	}

}
