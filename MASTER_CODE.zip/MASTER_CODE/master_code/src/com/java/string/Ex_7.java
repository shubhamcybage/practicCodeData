package com.java.string;

//Program to sort and get the distinct element from  the list.
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Ex_7 {

	public static void main(String[] args) {
		
		List<Integer> list=new ArrayList<>();
		list.add(10);
		list.add(25);
		list.add(89);
		list.add(74);
		list.add(41);
		list.add(41);
		
		System.out.println("============================================================");
		
		for(Integer l : list) {
			System.out.println(l);
		}
		
        System.out.println("============================================================");
		
		List<Integer> list2=list.stream().distinct().sorted().collect(Collectors.toList());
		
		for(Integer l : list2) {
			System.out.println(l);
		}
	}
}
