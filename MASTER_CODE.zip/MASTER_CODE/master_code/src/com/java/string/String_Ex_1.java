package com.java.string;

final class ImmuClass{
	
	final String name;
	
	public ImmuClass(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
	
}

public class String_Ex_1 {

	public static void main(String[] args) {

		ImmuClass im = new ImmuClass("55");
		String name1=im.getName();
		System.out.println(name1);
		
       
		
	}

}
