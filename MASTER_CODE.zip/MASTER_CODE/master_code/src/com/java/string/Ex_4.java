package com.java.string;

import java.util.Arrays;

public class Ex_4 {

	static boolean checkAnagram(char[] str1, char[] str2) {

		int Str1ln=str1.length;
		int str2ln=str2.length;
		
		if(Str1ln!=str2ln) {
			return false;
		}
		
		Arrays.sort(str1);
		Arrays.sort(str2);
		
		for(int i=0;i<Str1ln;i++) {
			if(str1[i]!=str2[i]) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {

		String str1 = "abcd";
		String str2 = "bcad";
		
		char[] charArr1=str1.toCharArray();
		char[] charArr2=str2.toCharArray();
		
		if(checkAnagram(charArr1,charArr2)) {
			System.out.println("The given String is Anagram");
		}else {
			System.out.println("The given String is not anagram");
		}

	}

}



//int strl1 = str1.length;
//int srtl2 = str2.length;
//
//if (strl1 != srtl2)
//	return false;
//
//Arrays.sort(str1);
//Arrays.sort(str2);
//
//for (int i = 0; i < strl1; i++) {
//	if (str1[i] != str2[i]) {
//		return false;
//	}
//}
//return true;



//String st1 = "abcd";
//String st2 = "bcad";
//
//char[] str1 = st1.toCharArray();
//char[] str2 = st2.toCharArray();
//
//if (checkAnagram(str1, str2)) {
//	System.out.println("Given String is Anagram");
//} else {
//	System.out.println("Given String is not Anagram");
//}