package com.java.string;

class PalindromeChecker {
	
	public static boolean isPalindrome(String str) {
		
		if(str.length()==0) {
			return false;
		}
		StringBuilder sb=new StringBuilder(str);
		StringBuilder s=sb.reverse();
		if(str.equals(s.toString())) {
			return true;
		}else {
			return false;
		}
		
		
	}
}

public class Ex_21 {

	public static void main(String[] args) {
		
		System.out.println(PalindromeChecker.isPalindrome("madam"));

	}

}
