package com.java.string;

class reverse{
	
	public static String reverseWord(String str) {
	    
		String[] word=str.split("\\s");
		String revWord="";
		for(String w:word) {
			StringBuilder sb=new StringBuilder(w);
			sb.reverse();
			revWord+=sb.toString()+" ";
		}
		return revWord;
	}
}

public class Ex_23 {

	public static void main(String[] args) {
		String x=reverse.reverseWord("My Name Is Shubham");
		System.out.println(x);
	}

}
