package com.java.string;

public class Ex_6 {

	public static void main(String[] args) {

		String str = "grass is greener on the other side";
		int freq[] = new int[str.length()];
		char minChar = str.charAt(0);
		char maxChar = str.charAt(0);
		int i, j, min, max;

		char String[] = str.toCharArray();

		for (i = 0; i < String.length; i++) {
			freq[i] = 1;
			for (j = i + 1; j < String.length; j++) {
				if (String[i] == String[j] && String[i] != ' ' && String[i] != '0') {
					freq[i]++;
					String[i] = '0';
				}
			}
		}

		min = max = freq[0];
		for (i = 0; i < freq.length; i++) {

			if (min > freq[i] && freq[i] != '0') {
				min = freq[i];
				minChar = String[i];
			}
			if (max < freq[i]) {
				max = freq[i];
				maxChar = String[i];
			}

		}
		System.out.println("Minimum occurring character: " + minChar);
		System.out.println("Maximum occurring character: " + maxChar);

	}

}
