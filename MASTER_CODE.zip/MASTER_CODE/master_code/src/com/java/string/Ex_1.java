package com.java.string;

//1.How to reverse String in java?
public class Ex_1 {

	public static void main(String[] args) {	  
//		String str="Shubham";
//		char[] charArr=str.toCharArray();
//		for (int i =charArr.length-1;i>=0; i--) {
//			System.out.print(charArr[i]);
//		}
		
		String s="shubham";
		s="Nagpure";
		System.out.println(s);
	
	}
}
