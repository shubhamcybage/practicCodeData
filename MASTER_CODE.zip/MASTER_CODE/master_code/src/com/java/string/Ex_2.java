package com.java.string;

//2.How to check if String is Palindrome?
public class Ex_2 {

	public static void main(String[] args) {

		String str1 = "madam";
		String str2="";
		char[] charArr = str1.toCharArray();
		for (int i = charArr.length-1; i >= 0; i--) {
			str2 = str2 + charArr[i];
		}
		
		if(str1.toLowerCase().equals(str2.toLowerCase())) {
			System.out.println("String is Palindrom...");
		}else {
			System.out.println("String is not Palindrom.....");
		}
	}
}
