package com.java.string;

public class NewEx_17 {
	
	public static void removeSpecialCharacters(String str) {
		String str1=str.replaceAll("[^a-zA-Z0-9]","");
		System.out.println(str1);
	}
	
	public static void removeSpecialCharacters1(String str) {
	   char[] c=str.toCharArray();
	  String str2 = null;
	   for(Character ch:c) {
		   if(Character.isDigit(ch) && Character.isAlphabetic(ch)) {
			   str2=str2+ch;
		   }
		}
	   System.out.println(str2);
	}

	public static void main(String[] args) {
		String str="$Ja#l$l@l%l7";
		removeSpecialCharacters(str);
		removeSpecialCharacters1(str);
	}
}
