package com.java.string;

import java.util.Arrays;

//4.Write a Java program to check whether two strings are anagram or not ?
public class NewEx_4 {

	public static void isAnagram(String st, String st1) {

		String str1 = st.replaceAll("\\s", st);
		String str2 = st1.replaceAll("\\s", st1);
		boolean status = true;
		if (str1.length() != str2.length()) {
			status = false;
		} else {
			char[] arrS1 = str1.toLowerCase().toCharArray();
			char[] arrS2 = str2.toLowerCase().toCharArray();

			Arrays.sort(arrS1);
			Arrays.sort(arrS2);

			status = Arrays.equals(arrS1,arrS2);
		}
		if(status) {
			System.out.println("Strings are Anagram");
		}else {
			System.out.println("Strings are not Anagram");
		}
	}

	public static void main(String[] args) {

		isAnagram("keep", "peek");

	}

}
