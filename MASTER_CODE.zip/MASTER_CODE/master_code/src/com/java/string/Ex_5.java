package com.java.string;

//program to remove all white spaces from a string
public class Ex_5 {

	public static void main(String[] args) {
        
      String str="Shubham is a good boy";
      String str2=str.replaceAll("\\s"," ");
      System.out.println(str2);
		
		
	}

}

