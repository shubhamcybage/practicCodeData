package com.java.string;


//13.Write a java program to reverse a given String by Preserving the Positions and Spaces ? 
public class NewEx_13 {

	public static void preserveSpacesReverse(String str) {
		
		char[] charArr = str.toCharArray();
		char[] result = new char[charArr.length];

		for (int i = 0; i < charArr.length; i++) {

			if (charArr[i] == ' ') {
				result[i] = ' ';
			}
		}

		int j = result.length - 1;
		for (int i1 = 0; i1 < charArr.length; i1++) {

			if (charArr[i1] != ' ') {

				if (result[j] == ' ') {
					j--;
				}
				result[j] = charArr[i1];
				j--;
			}
		}
		System.out.println(String.valueOf(result));
	}

	public static void main(String[] args) {
		String str = "My Name is Shubham";
		NewEx_13.preserveSpacesReverse(str);

	}

}
