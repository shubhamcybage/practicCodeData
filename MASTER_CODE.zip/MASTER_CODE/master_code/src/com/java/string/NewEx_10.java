package com.java.string;

//10.Write a java program to count number of words from the given string ?
public class NewEx_10 {

	  public static void main(String[] args) {
	        String str = "welcome to java   tutorial on Java2blog";
	 
	        int count = 1;
	 
	        for (int i = 0; i < str.length() - 1; i++)
	        {
	            if ((str.charAt(i) == ' ') && (str.charAt(i + 1) != ' '))
	            {
	                count++;
	            }
	        }
	        System.out.println("Number of words in a string : " + count);
	    }
	}
	 