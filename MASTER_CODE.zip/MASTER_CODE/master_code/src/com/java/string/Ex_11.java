package com.java.string;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class Ex_11 {
	
	static void removeDuplicate(char[] charArr, int n) {
		
		HashSet<Character> hs=new LinkedHashSet<>(n-1);
		
		for(char x:charArr) {
			hs.add(x);
		}
		
		for(char y:hs) {
			System.out.print(y);
		}
		
	}

	public static void main(String[] args) {
		String str="Shubhama";
		
		char[] charArr=str.toCharArray();
		
		int n=str.length();
		
		Ex_11.removeDuplicate(charArr,n);

	}

}
