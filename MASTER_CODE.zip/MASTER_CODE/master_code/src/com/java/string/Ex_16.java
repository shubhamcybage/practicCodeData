package com.java.string;
//String reverse Program without using any loop
class ReverseMe {
	public String reverseString(String s) {
		if (s.length() == 0)
			return "";
		return s.charAt(s.length() - 1) + reverseString(s.substring(0, s.length() - 1));

	}
}

public class Ex_16 {

	public static void main(String[] args) {
		ReverseMe rm = new ReverseMe();
		String rstr = rm.reverseString("Shubham");
		System.out.println(rstr);
	}

}
