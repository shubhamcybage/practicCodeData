package com.java.string;

public class Ex_24 {

	public static void main(String[] args) {
		
//		String str="shubham";
//		int l=str.length();
//		char first =str.charAt(0);
//		char last=str.charAt(l-1);
//		System.out.println("Char at : "+first);
//		System.out.println("Char at : "+last);
		
	    String str = "Welcome to Javatpoint portal";    
	    
	    for (int i = 0; i <= str.length()-1; i++) {
			if(i%2!=0) {
			    System.out.println("Char at "+i+" place "+str.charAt(i));  
			}
		}
	    int count=0;
	    for (int i = 0; i <= str.length()-1; i++) {
			if(str.charAt(i)=='c') {
				count++;
			}
		}
		System.out.println(count);

	}

}
