package com.java.string;

class stringFormatter{
	
	public static String capalitiseWord(String str) {
		String word[] = str.split("\\s");
		String capalitiseWord="";
		for (String w:word) {
			String first=w.substring(0,1);
			String afterFirst=w.substring(1);
			capalitiseWord+=first.toUpperCase()+afterFirst+" ";
		}
		return capalitiseWord;
	}
}

public class Ex_22 {

	public static void main(String[] args) {
	
		String sd=stringFormatter.capalitiseWord("my name is shubham");
        System.out.println(sd);		
 
	}

}
