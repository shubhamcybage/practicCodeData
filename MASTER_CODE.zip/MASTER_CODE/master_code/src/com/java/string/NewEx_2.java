package com.java.string;
//Write a Java Program to reverse String Without using any Loops ?
public class NewEx_2 {
	
	public static String reverseStrings(String str) {
		if(str.length()==0) {
			return "";
		}
		return str.charAt(str.length()-1)+reverseStrings(str.substring(0,str.length()-1));
		
	}

	public static void main(String[] args) {
	
		System.out.println(NewEx_2.reverseStrings("Shubham"));

	}

}
