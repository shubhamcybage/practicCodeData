package com.java.string;

class reverseStr{
	
	public static void reverseString(String str) {
		
		StringBuffer sb=new StringBuffer(str);
		sb.reverse();
		System.out.println(sb);
		
	}
	
	public static void revString(String str) {
		String str1="";
		char[] ch=str.toCharArray();
		for (int i= str.length()-1;i>=0;i--) {
			str1+=ch[i];
		}
		System.out.println(str1);
		
	}
	
	public static String reString1(String str) {
		if(str.length()==0) {
			return "";
		}
		return str.charAt(str.length()-1)+reString1(str.substring(0,str.length()-1));
	}
	
	
}




public class Ex_20 {

	public static void main(String[] args) {
		
		reverseStr.reverseString("shubham");
		reverseStr.revString("Shubham");
        String s=reverseStr.reString1("Shubham");
        System.out.println(s);
	}

}
