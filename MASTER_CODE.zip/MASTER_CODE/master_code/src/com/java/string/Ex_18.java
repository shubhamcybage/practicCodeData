package com.java.string;

import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class Ex_18 {

	public static void main(String[] args) {
		
        StringBuilder s1=new StringBuilder("Shubham");
        StringBuilder s2=new StringBuilder(" Nagpure");
        StringBuilder s3=s1.append(s2);
        System.out.println(s3);
        
		
		String s4=new String("Rahul");
		String s5=new String("Sharma");
		
		String s=String.format("%s %s",s4,s5);
		System.out.println(s.toString());
		
		System.out.println(String.join(" ",s4,s5));
		
		
		StringJoiner x=new StringJoiner(",");
		x.add("Shubham");
		x.add("Nagpure");
		System.out.println(x);
		
		List<String> liststr = Arrays.asList("abc", "pqr", "xyz");
		
		String str1=liststr.stream().collect(Collectors.joining(","));
		System.out.println(str1);
		
		
		
		
		
		
	}

}
