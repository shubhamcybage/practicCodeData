package com.java.string;

final class College{

	final String panCardNumber;

	public College(String pcardNumber) {
		this.panCardNumber = pcardNumber;
	}

	public String getNumber() {
		return panCardNumber;
	}

}

public class Ex_19 {

	public static void main(String[] args) {

		College c=new College("Shubham");
		String s=c.getNumber();
		System.out.println(s);
		
		
	}

}
