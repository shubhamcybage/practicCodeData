package com.java.string;
//String white spaces removal
public class Ex_17 {

	public static void main(String[] args) {
		String str="Shubham is a bad boy";
		System.out.println(str.replace(" ", ""));
		System.out.println(str.replaceAll("\\s",""));
    }

}
