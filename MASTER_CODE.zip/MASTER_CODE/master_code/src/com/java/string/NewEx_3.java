package com.java.string;

//Write a Java Program to remove all the white spaces in the given string ?
public class NewEx_3 {

	public static void removeWhiteSpce() {
		String str = "My Name is Shubham";
		String str1 = str.replaceAll("\\s", "");
		System.out.println(str1);
	}

	public static void removeSpcaes(String str1) {
		char[] ch = str1.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < ch.length; i++) {
			if (str1.charAt(i) != ' ' && str1.charAt(i) != '\t') {
				sb.append(ch[i]);
			}
		}
		System.out.println(sb);
	}

	public static void main(String[] args) {
		NewEx_3.removeWhiteSpce();
		NewEx_3.removeSpcaes("My name is Ram");
	}

}
