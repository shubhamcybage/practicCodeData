package com.java.string;

public class NewEx_8 {

	public static void main(String[] args) {

		String str = "hdbahsdbk5651sdsdv5151sdv5sd42032cv8sd7v65s1dv";
		char[] chArr = str.toCharArray();
        String s="";
        String s1="";
		for (Character ch:chArr) {
            if(Character.isDigit(ch)) {
            	s+=ch;
            }else {
            	s1+=ch;
            }
		}
		System.out.println(s);
		System.out.println(s1);

	}

}
