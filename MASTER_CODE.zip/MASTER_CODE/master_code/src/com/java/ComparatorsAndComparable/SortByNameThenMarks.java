package com.java.ComparatorsAndComparable;

import java.util.Comparator;

public class SortByNameThenMarks implements Comparator<Students> {

	@Override
	public int compare(Students o1, Students o2) {
		if(o1.name.equals(o2.name)) {
			return o1.mark-o2.mark; 
		}else {
			return o1.name.compareTo(o2.name);
		}
	}

	

}