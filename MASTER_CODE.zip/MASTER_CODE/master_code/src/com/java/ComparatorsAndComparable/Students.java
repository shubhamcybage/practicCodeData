package com.java.ComparatorsAndComparable;



public class Students {
	
	int mark;
	String name;
	
	public Students(int mark,String name) {
		super();
		this.mark=mark;
		this.name=name;
	}

	@Override
	public String toString() {
		return "Students [mark=" + mark + ", name=" + name + "]";
	}

	public int getMark() {
		return mark;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	@Override
//	public int compareTo(Students obj) {
//		if(this.mark>obj.mark) {
//			return 1;
//		}else if(this.mark<obj.mark) {
//			return -1;
//		}
//		return this.name.compareTo(obj.name);
//	}

	
	//Logic for Decending Order 
//	@Override
//	public int compareTo(Students obj) {
//		if (this.mark > obj.mark)
//			return -1;
//		else if (this.mark < obj.mark)
//			return 1;
//		return 0;
//	}
	
	//Logic for Ascending Order 
//	@Override
//	public int compareTo(Students obj) {
//		if (this.mark > obj.mark)
//			return 1;
//		else if (this.mark < obj.mark)
//			return -1;
//		return this.name.compareTo(obj.name);
//	}



//	@Override
//	public int compareTo(Students obj) {
//		if(this.mark>obj.mark) {
//			return 1;			
//		}else if(this.mark<obj.mark) {
//			return -1;
//		}
//		return this.name.compareTo(obj.name);
//	}

//	public int compareTo(Students obj) {
//		if(this.mark>obj.mark)
//			return 1;
//		else if(this.mark<obj.mark)
//			return -1;
//		return this.name.compareTo(obj.name);
//	}

}
