package com.java.ComparatorsAndComparable;

import java.util.*;

public class MainClass {

	public static void main(String[] args) {

		List<Students> students = new ArrayList<>();
		students.add(new Students(23, "Shubham"));
		students.add(new Students(1, "Shubham"));
		students.add(new Students(25, "Rahul"));
		students.add(new Students(26, "Saket"));
		students.add(new Students(27, "Sourabh"));
		students.add(new Students(28, "Samir"));
		students.add(new Students(29, "Kali"));

//	    Collections.sort(students, (o1,o2)->o1.name.compareTo(o2.name));
		
//		Collections.sort(students,(o1,o2)->{
//			if (o1.name.equals(o2.name)) {
//				return o1.mark - o2.mark;
//			} else {
//				return o1.name.compareTo(o2.name);
//			}
//		});
		
     //Collections.sort(students);
		
		//Collections.sort(students,new SortByNameThenMarks());
//		
//	    Collections.sort(students,Comparator.comparing(Students::getMark)
//	    		.thenComparing(Students::getName));
		students.forEach(System.out::println);

	}
}


