package com.java.collections;

import java.util.HashSet;

public class Set_Ex_1 {

	public static void main(String[] args) {

       HashSet<Integer> hs=new HashSet<Integer>();
       
       hs.add(1);
  
       
       Integer first=hs.stream().findFirst().get();
       System.out.println(first);
        
       
      Integer second=hs.stream().skip(1).findFirst().get();
      System.out.println(second);
       
       
       

	}

}
