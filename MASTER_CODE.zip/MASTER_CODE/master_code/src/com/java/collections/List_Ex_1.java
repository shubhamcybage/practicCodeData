package com.java.collections;


import java.util.ArrayList;
import java.util.ListIterator;

public class List_Ex_1 {

	public static void main(String[] args) {
		
		ArrayList<String> list=new ArrayList<String>();
		
		list.add("Shubham");
		list.add("Nagpure");
		list.add("Lakshman");
		
		list.forEach((x)->{System.out.println(x);});
		
		ListIterator<String> itr=list.listIterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		

	}

}
