package com.java.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Ex_2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<>();
		li.add("Shubham");
		li.add("Nagpure");
		li.add("Ravi");
		li.add("Sham");
		li.add("Shubha");
	
		
		ListIterator<String> litr=li.listIterator();
		
	    while(litr.hasPrevious()) {
	    	System.out.println(litr.next());
	    }
	    
	    //li.forEach((x)->{System.out.println(x);});
		
	}

}
