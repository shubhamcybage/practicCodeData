package com.java.collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;

public class Ex_5 {

	public static void main(String[] args) {
		Set<Integer> q1=new TreeSet<>();
	     
	     q1.add(11);
	     q1.add(12);
	     q1.add(58);
	  
	   
	     q1.add(11);
	     
	     q1.forEach((a)->{
	     	System.out.println(a); 
	      });

	}

}
