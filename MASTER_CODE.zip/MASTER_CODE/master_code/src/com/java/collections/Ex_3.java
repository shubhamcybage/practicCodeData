package com.java.collections;

import java.util.Stack;

public class Ex_3 {

	public static void main(String[] args) {
		Stack<String> s=new Stack<>();
		s.push("Shubham");
		s.push(null);
		s.push("Shubham");
		s.push("Nagpure");
		
		s.forEach((arg)->{
			System.out.println(arg);
		});
		

	}

}
