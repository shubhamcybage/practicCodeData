package com.java.collections;

import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

public class HashTable_Ex_1 {

	public static void main(String[] args) {
		Hashtable<Integer,String> ht=new Hashtable<Integer,String>();
		
		ht.put(1, "Shubham");
		ht.put(2, "Rahul");
		ht.put(3, "Ramesh");
		ht.put(4, "Suresh");
		ht.put(5, "Kala");
		ht.put(6, "BolBacchan");
		
//		ht.forEach((k,v)->{System.out.println("Key :"+k+"value :"+v);});
//		System.out.println("=========================================================");
//		for (Map.Entry m:ht.entrySet()) {
//			System.out.println("Key :"+m.getKey()+"Value : "+m.getValue());
//			
//		}
		
		
		System.out.println(ht);
		ht.remove(1);
		System.out.println(ht);
		System.out.println(ht.getOrDefault(2,"Not Found"));
		System.out.println(ht.getOrDefault(89, "Not Found"));
		
	}

}
