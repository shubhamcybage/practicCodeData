package com.java.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;



public class Ex_1 {

	public static void main(String[] args) {

		List<String> li = new ArrayList<String>();
		li.add("Shubham");
		li.add("Nagpure");
		li.add("Arvi");

		for (String x : li) {
			System.out.println(x);
		}
		
		System.out.println("=========================================");

		li.forEach((e) -> {
			System.out.println(e);
		});
		
		System.out.println("=========================================");
		
		Iterator<String> iterator=li.iterator();
		
	    while(iterator.hasNext()) {
	    	System.out.println(iterator.next());
	    }
	    
	    Spliterator<String> sli=li.spliterator();
	    
	    sli.forEachRemaining(System.out::println);

	}
}