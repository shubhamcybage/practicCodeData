package com.java.collections;

import java.util.Hashtable;

class Book {
	String bookName;
	double bookPrice;

	Book(String bookName, double bookPrice) {
		this.bookName = bookName;
		this.bookPrice = bookPrice;
	}

	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", bookPrice=" + bookPrice + "]";
	}
	
	
}

public class HashTable_Ex_2 {

	public static void main(String[] args) {
		
		Hashtable<Integer,Book> hb=new Hashtable<Integer,Book>();
		
		Book b=new Book("Ram",100.00);
		Book b1=new Book("Gopal",99.00);

		hb.put(1, b);
		hb.put(2, b1);
		
		hb.forEach((k,v)->{System.out.println("Kay :"+k+"Value :"+v);});
		
	}

}
