package com.java.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;

public class ArrayListToHashMap {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<>(Arrays.asList("shubham", "Rahul", "Nikhil", "Nagpure"));

		HashMap<String, Integer> map = convertArrayListToHashMap(list);
		
		for(Entry<String,Integer> entry:map.entrySet()) {
			System.out.println(entry.getKey()+" "+entry.getValue());
		}

	}

	private static HashMap<String, Integer> convertArrayListToHashMap(ArrayList<String> list) {

		HashMap<String, Integer> hashMap = new HashMap<>();

		for (String s : list) {
			hashMap.put(s, s.length());
		}
		return hashMap;
	}

}
