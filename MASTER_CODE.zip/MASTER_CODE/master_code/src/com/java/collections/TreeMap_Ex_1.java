package com.java.collections;

import java.util.Map;
import java.util.TreeMap;

public class TreeMap_Ex_1 {

	public static void main(String[] args) {

      TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
      
      tm.put(1,"Shubham");
      tm.put(2,"Rahul");
      tm.put(3,"Nagpure");
      
      for(Map.Entry m:tm.entrySet()) {
    	  System.out.println(m);
      }
      tm.forEach((k,v)->{System.out.println("Key : "+k+"Value "+v);});

	}

}
