package com.java.collections;

import java.util.HashMap;

public class HashMap_Ex_1 {

	public static void main(String[] args) {
		
      HashMap<Integer,String> hm=new HashMap<Integer,String>();
      
      
      hm.put(1,"Shubham");
      hm.put(2,"Rahul");
      hm.put(3,"Ram");
      
      hm.put(null,"Kala");
 
      
      hm.forEach((k,v)->{System.out.println("Kay :"+k+"Value :"+v);});
		
		
	}

}
