package com.java.collections;

import java.util.PriorityQueue;
import java.util.Queue;

public class Ex_4 {

	public static void main(String[] args) {

     Queue<Integer> q1=new PriorityQueue<>();
     
     q1.add(11);
     q1.add(12);
     q1.add(58);

     
     System.out.println(q1.peek());
     System.out.println(q1.poll());

     System.out.println("============================================");
     
     q1.forEach((a)->{
    	System.out.println(a); 
     });
     

     
	}

}
