package com.java.collections;

import java.util.LinkedHashMap;

public class LinkedHashMap_Ex_1 {

	public static void main(String[] args) {
	
		LinkedHashMap<Integer,String> lm=new LinkedHashMap<Integer,String>();
		
		lm.put(1,"Shubham");
		lm.put(2,"Rahul");
		lm.put(3,"Ram");
		
		lm.forEach((k,v)->{System.out.println("Key : "+k+"Value :"+v);});
	}

}
