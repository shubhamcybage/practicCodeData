package com.java.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class HashMapToArrayList {

	public static void main(String[] args) {

		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("Shubham", 101);
		map.put("Rahul", 102);
		map.put("Shamal", 103);
		map.put("Ram", 104);
		map.put("Gaurav", 105);

//		Set<String> key = map.keySet();
//		ArrayList<String> listOfKey = new ArrayList<String>(key);
//
//		Collection<Integer> value = map.values();
//		ArrayList<Integer> listOfValues = new ArrayList<Integer>(value);
		
		ArrayList<String> listOfKeys=map.keySet().stream().collect(Collectors.toCollection(ArrayList::new));
		ArrayList<Integer> listOfValues=map.values().stream().collect(Collectors.toCollection(ArrayList::new));
		
		listOfKeys.forEach((x) -> {
			System.out.println(x);
		});
		System.out.println("==========================================================");
		listOfValues.forEach((z) -> {
			System.out.println(z);
		});

	}

}
