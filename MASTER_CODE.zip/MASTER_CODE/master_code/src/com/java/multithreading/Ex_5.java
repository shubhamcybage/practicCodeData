package com.java.multithreading;

public class Ex_5 extends Thread {

	public void run() {
		for (int i = 0; i < 10; i++) {

			try {
				Thread.sleep(1000);
				System.out.println(i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}

	public static void main(String[] args) {

		Ex_5 e5 = new Ex_5();
		e5.start();

	}

}
