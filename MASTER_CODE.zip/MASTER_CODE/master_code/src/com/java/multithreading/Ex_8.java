package com.java.multithreading;

public class Ex_8 extends Thread {

	static Thread mainThread;

	public void run() {

		try {
			mainThread.join();
			for (int i = 0; i <= 5; i++) {
				System.out.println(i + " " + Thread.currentThread().getName());
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) throws InterruptedException {
		mainThread = Thread.currentThread();
		Ex_8 ex8 = new Ex_8();
		ex8.start();

		try {
			for (int i = 0; i <= 5; i++) {
				System.out.println(i + " " + Thread.currentThread().getName());
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
