package com.java.multithreading;
//Creating Thread with Thread Class
public class Ex_1 extends Thread {

	public void run() {
		System.out.println("Thread is created.....");
	}
	
	public static void main(String[] args) {
		
		Ex_1 e1=new Ex_1();
		e1.start();
     }
}
