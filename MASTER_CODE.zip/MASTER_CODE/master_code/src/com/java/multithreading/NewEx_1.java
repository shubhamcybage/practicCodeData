package com.java.multithreading;

public class NewEx_1 extends Thread {

	public void run() {
		
		System.out.println("Thread is Running..........");
	}

	public static void main(String[] args) {

		NewEx_1 ex1 = new NewEx_1();
		ex1.start();

	}

}
