package com.java.multithreading;

public class NewEx_2 implements Runnable {

	public void run() {

		System.out.println("Thread is Running......");

	}

	public static void main(String[] args) {

		NewEx_2 ex2 = new NewEx_2();
		Thread th = new Thread(ex2);
		th.start();

	}

}
