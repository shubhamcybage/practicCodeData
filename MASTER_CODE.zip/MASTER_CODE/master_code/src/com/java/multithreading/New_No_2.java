package com.java.multithreading;

public class New_No_2 implements Runnable {
	
	@Override
	public void run() {
		System.out.println("Thread is executing.....");
		
	}


	public static void main(String[] args) {
		New_No_2 n11=new New_No_2();
		Thread th=new Thread(n11);
		th.start();
		

	}

	
}
