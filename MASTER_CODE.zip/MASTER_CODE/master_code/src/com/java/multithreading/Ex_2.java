package com.java.multithreading;
//Creating Thread using Runnable.....
public class Ex_2 implements Runnable {

	public void run() {

		System.out.println("Thread is created....");

	}

	public static void main(String[] args) {
        Ex_2 e2 = new Ex_2();
		Thread th = new Thread(e2);
		th.start();
	}
}
