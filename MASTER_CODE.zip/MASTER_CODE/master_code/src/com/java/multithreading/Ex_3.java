package com.java.multithreading;

public class Ex_3 extends Thread{
	
	public void run() {
		
		System.out.println("Thread is running..............");
		System.out.println(Thread.currentThread().getName());
	}
	

	public static void main(String[] args) {
		
		Ex_3 ex3=new Ex_3();
		ex3.run();
		System.out.println(Thread.currentThread().getName());
	}

}
