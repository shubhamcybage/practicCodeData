package com.java.multithreading;

class BookTheatureSeat {

	int total_seat = 10;

	void bookSeat(int seats) {
		synchronized (this) {
			if (total_seat >= seats) {
				System.out.println(seats + " Seats booked sucessfully");
				total_seat = total_seat - seats;
				System.out.println("Seats left :" + total_seat);
			} else {
				System.out.println("Sorry seats can not be booked");
				System.out.println("Seats left :" + total_seat);
			}
		}
	}

}

public class Ex_11 extends Thread {
	static BookTheatureSeat b;
	int seats;

	public void run() {
		b.bookSeat(seats);

	}

	public static void main(String[] args) {
		b = new BookTheatureSeat();

		Ex_11 ex11 = new Ex_11();
		ex11.seats = 7;
		ex11.start();

		Ex_11 ex111 = new Ex_11();
		ex111.seats = 6;
		ex111.start();
	}

}
