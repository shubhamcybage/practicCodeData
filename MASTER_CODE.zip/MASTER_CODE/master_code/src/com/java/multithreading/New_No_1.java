package com.java.multithreading;
//Creating Threads using Thread class
public class New_No_1 extends Thread{
	
	public void run() {
		System.out.println("Thread is executing............");
	}

	public static void main(String[] args) {
		
		New_No_1 n1=new New_No_1();
		n1.start();
	
	}

}
