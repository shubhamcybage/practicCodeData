package com.java.multithreading;

class BookTheatureSeat1 {

	static int total_seat = 10;

	static synchronized void bookSeat(int seats) {

		if (total_seat >= seats) {
			System.out.println(seats + " Seats booked sucessfully");
			total_seat = total_seat - seats;
			System.out.println("Seats left :" + total_seat);
		} else {
			System.out.println("Sorry seats can not be booked");
			System.out.println("Seats left :" + total_seat);
		}
	}

}

class MyThread1 extends Thread {
	BookTheatureSeat1 b;
	int seats;

	MyThread1(BookTheatureSeat1 b, int seats) {
		this.b = b;
		this.seats = seats;
	}

	public void run() {
		b.bookSeat(seats);
	}
}

class MyThread2 extends Thread {
	BookTheatureSeat1 b;
	int seats;

	MyThread2(BookTheatureSeat1 b, int seats) {
		this.b = b;
		this.seats = seats;
	}

	public void run() {
		b.bookSeat(seats);
	}
}

public class Ex_12 {

	public static void main(String[] args) {
		
		BookTheatureSeat1 b1=new BookTheatureSeat1();
		
		MyThread1 t1=new MyThread1(b1,7);
		t1.start();
		MyThread1 t2=new MyThread1(b1,6);
		t2.start();
		
        BookTheatureSeat1 b2=new BookTheatureSeat1();
		
		MyThread1 t3=new MyThread1(b2,8);
		t3.start();
		MyThread1 t4=new MyThread1(b2,9);
		t4.start();
	}

}
