package com.java.multithreading;

public class Ex_10 extends Thread {

	public void run() {
		
		
	
		System.out.println(Thread.currentThread().isInterrupted());
		System.out.println(Thread.interrupted());
		
		try {
			for (int i = 0; i <= 5; i++) {
				System.out.println(i);
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public static void main(String[] args) {

		Ex_10 ex10 = new Ex_10();
		ex10.start();
		ex10.interrupt();

	}

}
