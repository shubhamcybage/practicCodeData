package com.java.multithreading;

public class Ex_6 extends Thread {

	public void run() {
		try {
			for (int i = 0; i <= 10; i++) {
				Thread.sleep(1000);
				System.out.println(i +" : "+Thread.currentThread().getName() );
			}
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		Ex_6 ex6 = new Ex_6();
		ex6.start();
		Ex_6 ex61 = new Ex_6();
		ex61.start();

	}

}
