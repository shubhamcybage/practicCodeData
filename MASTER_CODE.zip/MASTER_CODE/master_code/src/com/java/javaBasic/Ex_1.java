package com.java.javaBasic;
//Method Overriding

class Bike{
	
	 void run() {
		System.out.println("Running....");
	}
}

public class Ex_1 extends Bike{

	void run() {
		System.out.println("I am running.......");
	}
	
	public static void main(String[] args) {
		
		Ex_1 ex=new Ex_1();
		ex.run();

	}

}
