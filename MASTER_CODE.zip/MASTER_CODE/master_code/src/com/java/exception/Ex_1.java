package com.java.exception;

class InvalidAgeException extends Exception {
	public InvalidAgeException(String errorMessage) {
		super(errorMessage);
	}
}

public class Ex_1 {

	static void validate(int age) throws InvalidAgeException {
		if (age < 18) {
			throw new InvalidAgeException("Age is Invalid.....");
		}
	}

	public static void main(String[] args) {

		try {
			validate(3);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
