package com.java8.MethodReference;

interface Messageable {
	Message getMessage(String msg);
}

class Message {

	Message(String msg) {

		System.out.print(msg);

	}
}

public class Example_3 {

	public static void main(String[] args) {
		Messageable messageable=Message::new;
		messageable.getMessage("Shubham");
	}

}
