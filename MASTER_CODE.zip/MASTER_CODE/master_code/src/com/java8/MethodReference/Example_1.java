package com.java8.MethodReference;

interface Sayable{
	
	void say();
}

public class Example_1 {

	public static void saySomething() {
		System.out.println("Saysomething.......");
	}
	
	public static void main(String[] args) {
	
		Sayable sayable=Example_1::saySomething;
		sayable.say();

	}

}
