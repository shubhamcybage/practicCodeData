package com.java8.MethodReference;

interface Sayable1{
	void say();
}

public class Example_2 {
	
	public void saySomething() {
		System.out.println("Lets Say something.....");
	}

	public static void main(String[] args) {
		
		//Example_2 ex1=new Example_2();
		
		Sayable1 sayable1=new Example_2()::saySomething;
		sayable1.say();

	}

}
