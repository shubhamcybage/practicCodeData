package com.java8.lambadaExpression;

public class NewEx_2 {

	public static void main(String[] args) {
	
		Runnable r=new Runnable() {
			public void run() {
				System.out.println("Thread is running...");
			}
		};
		Thread th=new Thread(r);
		th.start();

		Runnable r1=()->{
			System.out.println("Thread1 is running......");
		};
		Thread th1=new Thread(r1);
		th1.start();
	}
}
