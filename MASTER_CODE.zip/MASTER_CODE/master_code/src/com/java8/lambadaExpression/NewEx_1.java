package com.java8.lambadaExpression;

import java.util.ArrayList;
import java.util.List;

@FunctionalInterface
interface Drawable {
	public String draw(String name);
}

@FunctionalInterface
interface Addable{
	public int add(int a,int b);
}

@FunctionalInterface
interface Sayable{
	public String Say();
}

public class NewEx_1 {

	public static void main(String[] args) {

		Drawable d = (name) -> {
			return "My Name is Shubham "+name;
		};
		System.out.println(d.draw("Nagpure"));
		
		Addable a=(int x,int y)->(x+y);
		System.out.println(a.add(10,20));
		
		Addable a1=(int x,int y)->{
           return x+y;
		};
		System.out.println(a1.add(10,20));
		
		List<String> li=new ArrayList<String>();
		li.add("Shubham");
		li.add("Nagpure");
		li.add("Ram");
		li.add("Kamla");
		
		li.forEach((x)->{
			System.out.println(x);
		});
		
		Sayable s=()->{
			
			String str1="Shubham";
			return "My Name is"+str1;
			
		};
		System.out.println(s.Say());
		
	}

}
