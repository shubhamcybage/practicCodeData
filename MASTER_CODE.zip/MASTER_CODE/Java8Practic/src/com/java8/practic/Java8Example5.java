package com.java8.practic;

interface Messageable{
	
    Message getMessage(String msg);  
}

class Message{
	
	Message(String msg){
		System.out.println(msg);
	}
}

public class Java8Example5 {

	public static void main(String[] args) {
		
		Messageable hello=Message::new;
		hello.getMessage("Shubham");

	}

}
