package com.java8.practic;

import java.util.*;

interface Drawable{
	
	String draw(String name);
}

interface Addable{
	
	int add(int a,int b);
}

public class Java8Example1 {

	public static void main(String[] args) {
		
//		Drawable d=new Drawable() {
//			public void draw() {
//				System.out.println("Drawing the Painting");
//			}
//		};
//		d.draw();
		
		Drawable d=(name)->{
				return "Shubham is Happy"+name;
	    };
		
		System.out.println(d.draw(" Shubham"));
		
		Addable a1=(a,b)->(a+b);
		System.out.println(a1.add(10,20));
		
		
		List<String> list=new ArrayList<String>();  
        list.add("ankit");  
        list.add("mayank");  
        list.add("irfan");  
        list.add("jai");  
        
        list.forEach((e)->System.out.println(e));
        
        
	}
	

	
}
