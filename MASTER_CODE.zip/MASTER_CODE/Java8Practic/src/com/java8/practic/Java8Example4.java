package com.java8.practic;

interface Sayable{
	
	 public void say();
	 
}

public class Java8Example4 {
	
	public  void saySomething() {
		System.out.println("Say Something......");
	}

	public static void main(String[] args) {
		Java8Example4 j8E=new Java8Example4();
		Sayable sayable=j8E::saySomething;
		sayable.say();
	}

}
