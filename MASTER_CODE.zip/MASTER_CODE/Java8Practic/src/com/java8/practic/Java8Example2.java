package com.java8.practic;

public class Java8Example2 {

	public static void main(String[] args) {

		Runnable r1 = new Runnable() {
			@Override
			public void run() {
				System.out.println("Shubham is My Name");
			}
		};
		Thread th = new Thread(r1);
		th.start();
		
		Runnable r2 = ()->{
				System.out.println("Shubham is My Name");
			};
		Thread th1 = new Thread(r2);
		th1.start();
		
		
		
		

	}

}
