package com.java.singletonclass;

class SingletonClass1{
	
	private static SingletonClass1 singleton=null;
	
	private SingletonClass1(){
		
	}
	
	public static SingletonClass1 getInstance() {
		if(singleton==null) {
			singleton=new SingletonClass1();
		}	
		return singleton;
	}
	
}

public class SingleClassExample2 {

	public static void main(String[] args) {
		
		SingletonClass1 a=SingletonClass1.getInstance();
		SingletonClass1 b=SingletonClass1.getInstance();
		SingletonClass1 c=SingletonClass1.getInstance();
		
		System.out.println("Hashcode of x is " + a.hashCode());
		System.out.println("Hashcode of y is " + b.hashCode());
		System.out.println("Hashcode of z is " + c.hashCode());

		if (a == b && b == c) {
			System.out.println("Three objects point to the same memory location on the heap i.e, to the same object");
		} else {
			System.out.println("Three objects DO NOT point to the same memory location on the heap");
		}
	}

}
