package com.java.singletonclass;

class SingletonClass {

	private static SingletonClass singletonClass=null;

	private SingletonClass() {

	}

	public static SingletonClass getInstance() {
		if (singletonClass == null) {
	         singletonClass = new SingletonClass();

		}
		return singletonClass;
	}
}

public class SingletonClassExample {

	public static void main(String args[]) {

		SingletonClass x = SingletonClass.getInstance();
		SingletonClass y = SingletonClass.getInstance();
		SingletonClass z = SingletonClass.getInstance();

		System.out.println("Hashcode of x is " + x.hashCode());
		System.out.println("Hashcode of y is " + y.hashCode());
		System.out.println("Hashcode of z is " + z.hashCode());

		if (x == y && y == z) {
			System.out.println("Three objects point to the same memory location on the heap i.e, to the same object");
		} else {
			System.out.println("Three objects DO NOT point to the same memory location on the heap");
		}
	}

}
