package com.java.practicQuestions.ArraysAndStrings;

import java.util.Arrays;
//11.Write a Java program to check whether two strings are anagram or not? 
public class Example_9 {
	
	public static boolean checkAnagram(char[] chArr1,char[] chArr2) {
		
		int strlen1=chArr1.length;
		int strlen2=chArr2.length;
		
		if(strlen1!=strlen2) {
			return false;
		}
		
		Arrays.sort(chArr1);
		Arrays.sort(chArr2);
		
		for (int i = 0; i < chArr2.length; i++) {
			if(chArr1[i]!=chArr2[i]) {
				return false;
			}
		}
		return true;
		
	}

	public static void main(String[] args) {
		
		String str1 = "abdc";
		String str2 = "cdab";
		
		char[] chaArr1=str1.toCharArray();
		char[] chaArr2=str2.toCharArray();
		
		if(checkAnagram(chaArr1,chaArr2)) {
			System.out.println("String is Anagram");
		}else {
			System.out.println("String is not Anagram");
		}
		
	}

}
