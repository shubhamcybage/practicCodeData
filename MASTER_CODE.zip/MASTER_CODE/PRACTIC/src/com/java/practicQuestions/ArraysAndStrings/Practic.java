package com.java.practicQuestions.ArraysAndStrings;

public class Practic {
	
	public static String reverseString(String str) {
		
//		StringBuilder sb = new StringBuilder(str);
//		sb.reverse();
//		System.out.println(sb);
//		String str1="";
//		for(int i=str.length()-1;i>=0;i--) {
//			str1+=str.charAt(i);
//		}
//		
//		System.out.println(str1);
		
		if(str.length()==0) {
			return "";
		}
		return str.charAt(str.length()-1)+reverseString(str.substring(0,str.length()-1));
		
		
	}
	
	public static void main(String[] args)  {
		String str = "Shubham Nagpure";
		System.out.println(reverseString(str));
	}

}
