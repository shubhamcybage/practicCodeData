package com.java.practicQuestions.ArraysAndStrings;
//4.Write a Java Program to Sort the Array in Java (Bubble Sort) ?
public class Example_3 {

	public static void sortUsingBubbleSort(int[] arr) {
		int n = arr.length;
		for (int i = 0; i < n; i++) {
			boolean swapped = false;
			for (int j = 0; j < n - i - 1; j++) {
				if (arr[j + 1] < arr[j]) {
					swapped = true;
					int temp = arr[j + 1];
					arr[j + 1] = arr[j];
					arr[j] = temp;
				}
			}
			if(!swapped) {
				break;
			}

		}

	}

	public static void main(String[] args) {
		int[] arr = { 4, 88, 5, 1, 2, 7, 99 };
		System.out.println("Array Before Sorting........");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		sortUsingBubbleSort(arr);
		System.out.println("Array After Sorting.........");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

}
