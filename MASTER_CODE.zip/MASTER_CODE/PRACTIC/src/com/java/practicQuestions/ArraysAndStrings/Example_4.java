package com.java.practicQuestions.ArraysAndStrings;
//5.Write a Java Program to remove all the white spaces in the given string ? 
public class Example_4 {

	public static void removeWhiteSpaces(String str) {
		String str1 = "";
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != ' ' && str.charAt(i) != '\t') {
				str1 += str.charAt(i);
			}
		}
		System.out.println(str1);
	}

	public static void main(String[] args) {
		String str = "My Name is Shubham";
		removeWhiteSpaces(str);

	}

}
