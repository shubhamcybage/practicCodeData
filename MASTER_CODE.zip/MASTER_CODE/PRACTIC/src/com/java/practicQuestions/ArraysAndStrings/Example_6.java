package com.java.practicQuestions.ArraysAndStrings;
//7.Write a Java Program to find the Second Largest Element in the Array ? //O(n)
public class Example_6 {
	
	public static void print2LargestElement(int[] arr,int arr_len) {
		int firstElement,secondElement;
		if(arr_len<2) {
			System.out.println("Invalid Input.....");
			return;
		}
		firstElement=secondElement=Integer.MIN_VALUE;
		for (int i = 0; i < arr_len; i++) {
			if(arr[i]>firstElement) {
				firstElement=secondElement;
				secondElement=arr[i];
			}else if(arr[i]>secondElement && arr[i]!=secondElement) {
				secondElement=arr[i];
			}
		}
		System.out.println("Second Largest Element is : "+secondElement);
	}

	public static void main(String[] args) {
		int[] arr={5,7,1,9,8,77,44,66};
		int arr_length=arr.length;
		print2LargestElement(arr,arr_length);
	}

}
