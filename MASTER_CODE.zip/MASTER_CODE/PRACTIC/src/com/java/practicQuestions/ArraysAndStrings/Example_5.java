package com.java.practicQuestions.ArraysAndStrings;

//6.Write a Java Program to find duplicate characters in a String ?   

import java.util.HashMap;
import java.util.Set;

public class Example_5 {
	
	public static void findDuplicateCharacter(String str) {
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		char[] chaArr=str.toCharArray();
		for(Character ch:chaArr) {
			if(hm.containsKey(ch)) {
				hm.put(ch,hm.get(ch)+1);
			}else {
				hm.put(ch,1);
			}
		}
		
		Set<Character> st=hm.keySet();
		for (Character c:st) {
			if(hm.get(c)>1) {
				System.out.println(c + " is : " + hm.get(c) + " times ");
			}
		}
	}

	public static void main(String[] args) {
		
		String str="My Name is Shubham";
		findDuplicateCharacter(str);
		
		
	}

}
