package com.java.practicQuestions.ArraysAndStrings;

public class Example_20 {
	
	
	 public static void main(String args[])
	    {
	        double principle = 10000, rate = 10.25, time = 5;
//	        double CI = principle *
//	                    (Math.pow((1 + rate / 100), time));
	          
	        double CI=principle*(Math.pow((1+rate/100),time));
	        
	        System.out.println("Compound Interest is "+ CI);
	    }

}
