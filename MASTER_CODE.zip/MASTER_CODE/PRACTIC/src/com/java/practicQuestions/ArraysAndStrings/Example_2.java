package com.java.practicQuestions.ArraysAndStrings;

//2.Write a Java Program to reverse String Without using any Loops ?  

public class Example_2 {

	public static void removeSpecialCharacters(String str) {
		String str1=str.replaceAll("[^a-zA-Z0-9]","");
		System.out.println(str1);
	}

	public static void removeSpecialCharacters1(String str) {
		String str2="";
		for(int i=0;i<=str.length()-1;i++) {
			if((str.charAt(i)>=65 && str.charAt(i)<=122) || (str.charAt(i)>48 && str.charAt(i)<=57)) {
				str2+=str.charAt(i);
			}
		}
		System.out.println(str2);
	}

	public static void main(String[] args) {
		String str = "$Ja#l$l@l%l7";
		removeSpecialCharacters(str);
		removeSpecialCharacters1(str);
	}

}
