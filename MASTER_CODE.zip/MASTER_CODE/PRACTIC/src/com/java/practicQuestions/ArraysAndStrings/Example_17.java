package com.java.practicQuestions.ArraysAndStrings;
//17.Write a Java Program to find the largest Element in the Array ? 
public class Example_17 {
	
	public static void largestElemnt(int[] arr) {
		
		int max=arr[0];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println(max);
	}

	public static void main(String[] args) {
		
		int[] arr={5,8,7,4,33,99,22,11,44,5};
		largestElemnt(arr);
	}

}
