package com.java.practicQuestions.ArraysAndStrings;

import java.util.*;
//9.Write a Java Program to find the Duplicate Element in the Array ? 
public class Example_7 {
	
	public static void printDuplicateElements(int[] arr) {
		
		HashMap<Integer,Integer> hm=new HashMap<>();
		for(Integer i:arr) {
			if(hm.containsKey(i)) {
				hm.put(i,hm.get(i)+1);
			}else {
				hm.put(i,1);
			}
		}
		
		Set<Integer> st=hm.keySet();
		for(Integer ii:st) {
			if(hm.get(ii)>1) {
				System.out.println(ii + " is "+hm.get(ii)+" times ");
			}
		}
	}

	public static void main(String[] args) {
		
		int[] arr={7,4,9,5,6,3,8,3,2,8};
		printDuplicateElements(arr);
		

	}

}
