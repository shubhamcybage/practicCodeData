package com.java.practicQuestions.ArraysAndStrings;

//15.Write a java Program to convert String into Integer and Integer into String in Java ? 
public class Example_15 {

	public static void main(String[] args) {

		// Converting String into Integer

		// 1st way
		String str1 = "5";
		int result = Integer.parseInt(str1); // Using Integer.parsrInt()
		System.out.println(result);

		// 2nd way
		String str2 = "5";
		Integer result2 = Integer.valueOf(str2); // Using Integer.valueOf()
		System.out.println(result2);

		// Converting Integer into String

		int x = 5;
		// 1st way
		String str = Integer.toString(x); // using Integer.toString()
		System.out.println(str);

		// 2nd way
		String str3 = String.valueOf(x); // using String.valueOf()
		System.out.println(str3);

	}

}
