package com.java.practicQuestions.ArraysAndStrings;

//13.Write a java program to to count the total number of vowels and consonants in a string ?
public class Example_13 {

	public static void totalCountForVowelsAndConsonent(String str) {
		int cVowels = 0, cConsonent = 0;
		String str1 = str.toLowerCase();
		for (int i = 0; i < str1.length(); i++) {
			if (str1.charAt(i) == 'a' || str1.charAt(i) == 'e' || str1.charAt(i) == 'i' || str1.charAt(i) == 'o'
					|| str1.charAt(i) == 'u') {
				cVowels++;
			} else if (str1.charAt(i) >= 'a' && str1.charAt(i) <= 'z') {
				cConsonent++;
			}
		}
		System.out.println("Consonent Present in the String : " + cConsonent);
		System.out.println("vowels Present in the String : " + cVowels);
	}

	public static void main(String[] args) {

		String str = "My Name is Shubham";
		Example_13.totalCountForVowelsAndConsonent(str);

	}

}
