package com.java.practicQuestions.ArraysAndStrings;

//14.Write a java program to extract alphabets and digits from a given string ?
public class Example_14 {

	public static void extractAlphabetAndDigit(String str) {

		String stAlphabets = "";
		String stDigits = "";
		String str1 = str.toLowerCase();
		for (int i = 0; i < str1.length(); i++) {
			if (str1.charAt(i) >= 65 && str1.charAt(i) <= 122) {
				stAlphabets += str1.charAt(i);
			} else if (str1.charAt(i) >= 48 && str1.charAt(i) <= 57) {
				stDigits += str1.charAt(i);
			}
		}

		System.out.println("Alphabets present in the String : " + stAlphabets);
		System.out.println("Digits present in the String : " + stDigits);

	}

	public static void main(String[] args) {

		String str = "My Name is Shubham 1456 55 Hello by";
		Example_14.extractAlphabetAndDigit(str);
	}

}
