package com.java.practicQuestions.ArraysAndStrings;

//1.Write a Java Program to reverse a String in Java ?  
//2.Write a Java Program to reverse String Without using any Loops ?  

public class Example_1 {
	
	public static void reverseString(String str) {
		StringBuilder sb=new StringBuilder(str);
		sb.reverse();
		System.out.println(sb);
	}
	
	public static void reverseString1(String str) {
		String str1="";
		for (int i=str.length()-1;i>=0; i--) {
			str1+=str.charAt(i);
		}
		System.out.println(str1);
	}
	
	public static String reverseString2(String str) {
		if(str.length()==0){
			return "";
		}
		return str.charAt(str.length()-1)+reverseString2(str.substring(0,str.length()-1));
	}

	public static void main(String[] args) {
		String str="My Name is Shubham";
		reverseString(str);
		reverseString1(str);
        System.out.println(	reverseString2(str));
	}

}
