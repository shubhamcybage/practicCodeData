package com.java.practicQuestions.ArraysAndStrings;

public class Example_10 {

	public static void main(String[] args) {

		String str = "civic";
		StringBuilder sb = new StringBuilder(str);
		sb.reverse();
		if (sb.equals(str)) {
			System.out.println("String is Palindrom");
		} else {
			System.out.println("String is not Palindrom");
		}

	}

}
