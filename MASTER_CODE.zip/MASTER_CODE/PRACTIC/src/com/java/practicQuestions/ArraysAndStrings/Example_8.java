package com.java.practicQuestions.ArraysAndStrings;
//10.Write a java program to find the frequency of a particular character from a given string ? 
public class Example_8 {
	
	public static void findFrequency(String str) {
		int count=0;
		char search='a';
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i)==search) {
				count++;
			}
		}
		System.out.println("Frequency of a is "+count);
	}

	public static void main(String[] args) {
		
		String str="mynameisshubham";
		findFrequency(str);
	}

}
