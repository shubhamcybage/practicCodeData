module Java8ExamplePractic {
}